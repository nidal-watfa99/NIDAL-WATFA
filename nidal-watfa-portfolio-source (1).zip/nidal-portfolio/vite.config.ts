import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';

// base './' produces relative asset paths, so the same build works on
// https://<user>.github.io/, https://<user>.github.io/<repo>/ and Codeberg Pages.
export default defineConfig({
  base: './',
  plugins: [react()],
  build: { target: 'es2019', sourcemap: false, chunkSizeWarningLimit: 300 },
});
