import { createContext, useContext, useEffect, useMemo, useState, type ReactNode } from 'react';
import en, { type Dict } from './en';
import ar from './ar';
import es from './es';

export type Lang = 'en' | 'ar' | 'es';
export const LANGS: { id: Lang; short: string; label: string }[] = [
  { id: 'en', short: 'EN', label: 'English' },
  { id: 'ar', short: 'العربية', label: 'العربية' },
  { id: 'es', short: 'ES', label: 'Español' },
];
const DICTS: Record<Lang, Dict> = { en, ar, es };
const KEY = 'nw-lang';

function initialLang(): Lang {
  try {
    const q = new URLSearchParams(location.search).get('lang');
    if (q === 'en' || q === 'ar' || q === 'es') return q;
    const s = localStorage.getItem(KEY);
    if (s === 'en' || s === 'ar' || s === 'es') return s;
  } catch { /* storage may be blocked */ }
  const nav = (navigator.language || 'en').slice(0, 2);
  return nav === 'ar' ? 'ar' : nav === 'es' ? 'es' : 'en';
}

interface Ctx { lang: Lang; t: Dict; dir: 'rtl' | 'ltr'; setLang: (l: Lang) => void; }
const I18nContext = createContext<Ctx | null>(null);

export function I18nProvider({ children }: { children: ReactNode }) {
  const [lang, setLang] = useState<Lang>(initialLang);
  const dir = lang === 'ar' ? 'rtl' : 'ltr';
  useEffect(() => {
    const html = document.documentElement;
    html.lang = lang;
    html.dir = dir;
    document.title = DICTS[lang].meta.title;
    try { localStorage.setItem(KEY, lang); } catch { /* ignore */ }
    const url = new URL(location.href);
    url.searchParams.set('lang', lang);
    history.replaceState(null, '', url);
  }, [lang, dir]);
  const value = useMemo(() => ({ lang, t: DICTS[lang], dir, setLang }), [lang, dir]) as Ctx;
  return <I18nContext.Provider value={value}>{children}</I18nContext.Provider>;
}

export function useI18n() {
  const c = useContext(I18nContext);
  if (!c) throw new Error('useI18n outside provider');
  return c;
}

export function formatDate(iso: string | null | undefined, lang: Lang) {
  if (!iso) return '';
  const d = new Date(iso);
  if (isNaN(+d)) return '';
  const locale = lang === 'ar' ? 'ar-SY-u-nu-latn' : lang === 'es' ? 'es-ES' : 'en-GB';
  return d.toLocaleDateString(locale, { year: 'numeric', month: 'short', day: 'numeric' });
}
