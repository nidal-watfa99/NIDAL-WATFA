import { useEffect, useRef, useState } from 'react';
import { LANGS, useI18n } from '../i18n';
import { Logo } from './Logo';
import { IconClose, IconMenu } from './Icons';

const SECTIONS = ['home', 'ecosystem', 'projects', 'about', 'contact'] as const;

export function Header() {
  const { t, lang, setLang } = useI18n();
  const [open, setOpen] = useState(false);
  const btnRef = useRef<HTMLButtonElement>(null);
  const panelRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (!open) return;
    const onKey = (e: KeyboardEvent) => {
      if (e.key === 'Escape') { setOpen(false); btnRef.current?.focus(); }
    };
    document.addEventListener('keydown', onKey);
    panelRef.current?.querySelector<HTMLAnchorElement>('a')?.focus();
    return () => document.removeEventListener('keydown', onKey);
  }, [open]);

  return (
    <>
      <a className="skip-link" href="#main">{t.nav.skip}</a>
      <header className="site-header">
        <div className="container header-inner">
          <a href="#home" className="brand" aria-label="Nidal Watfa — home">
            <Logo size={34} />
            <span className="brand-word" aria-hidden="true">NIDAL WATFA</span>
          </a>
          <div className="header-actions">
            <div className="lang-switch" role="group" aria-label={t.nav.language}>
              {LANGS.map((l) => (
                <button key={l.id} type="button" lang={l.id} aria-pressed={lang === l.id} onClick={() => setLang(l.id)} title={l.label}>
                  {l.short}
                </button>
              ))}
            </div>
            <button ref={btnRef} type="button" className="icon-btn" aria-expanded={open} aria-controls="site-menu" aria-label={open ? t.nav.close : t.nav.menu} onClick={() => setOpen((o) => !o)}>
              {open ? <IconClose /> : <IconMenu className="flip-rtl" />}
            </button>
          </div>
        </div>
      </header>
      {open && <div className="menu-backdrop" onClick={() => setOpen(false)} aria-hidden="true" />}
      <div id="site-menu" ref={panelRef} className="menu-panel" data-open={open} aria-hidden={!open} {...(!open ? { inert: '' } : {})}>
        <nav className="container" aria-label="Main">
          <ul>
            {SECTIONS.map((s, i) => (
              <li key={s}>
                <a href={`#${s}`} onClick={() => setOpen(false)} tabIndex={open ? 0 : -1}>
                  {t.nav[s]}
                  <span className="idx">0{i + 1}</span>
                </a>
              </li>
            ))}
          </ul>
        </nav>
      </div>
    </>
  );
}
