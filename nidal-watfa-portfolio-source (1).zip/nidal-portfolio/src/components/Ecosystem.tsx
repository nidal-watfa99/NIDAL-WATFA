import { PROFILES } from '../content/profile';
import { useI18n } from '../i18n';
import { BrandIcon, IconArrowUpRight } from './Icons';

export function Ecosystem() {
  const { t } = useI18n();
  return (
    <section id="ecosystem" className="section" aria-labelledby="eco-title">
      <div className="container">
        <div className="section-head reveal">
          <h2 id="eco-title" className="section-title">{t.ecosystem.title}</h2>
          <p className="section-sub">{t.ecosystem.subtitle}</p>
        </div>
        <ul className="eco-grid" role="list" style={{ listStyle: 'none', margin: 0, padding: 0 }}>
          {PROFILES.map((p) => (
            <li key={p.id} className="reveal">
              <a className="glass eco-card" href={p.url} target="_blank" rel="noopener noreferrer me" aria-label={`${p.name} (${p.handle}) — ${t.ecosystem.desc[p.id]}`} title={`${p.name} · ${p.handle}`}>
                <span className="eco-icon"><BrandIcon id={p.id} /></span>
                <span>
                  <span className="eco-name">{p.name}</span>
                  <span className="eco-desc" style={{ display: 'block' }}>{t.ecosystem.desc[p.id]}</span>
                </span>
                <span className="eco-arrow" aria-hidden="true"><IconArrowUpRight /></span>
              </a>
            </li>
          ))}
        </ul>
      </div>
    </section>
  );
}
