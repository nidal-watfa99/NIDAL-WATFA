import { useEffect, useMemo, useState } from 'react';
import { PROFILES } from '../content/profile';
import { formatDate, useI18n } from '../i18n';
import { techOf, type Project, type SourcePlatform, type useProjects } from '../lib/projects';
import { normalize } from '../assistant/engine';
import { BrandIcon, IconArrowUpRight, IconSearch } from './Icons';

type Filter = 'all' | SourcePlatform;
const PLATFORMS: SourcePlatform[] = ['github', 'gitlab', 'codeberg'];

function ProjectCard({ p }: { p: Project }) {
  const { t, lang } = useI18n();
  const desc = p.descriptions?.[lang] ?? p.description;
  const tech = techOf(p);
  return (
    <article className={`glass p-card${p.featured ? ' is-featured' : ''}`}>
      <div className="p-top">
        <span className="p-platform"><BrandIcon id={p.platform} /> {t.platforms[p.platform]}</span>
        {p.featured && <span className="badge-featured">{t.projects.featured}</span>}
      </div>
      <h3 className="p-name">{p.name}</h3>
      {desc ? <p className="p-desc" dir="auto">{desc}</p> : <p className="p-desc empty">{t.projects.noDescription}</p>}
      {tech.length > 0 && (
        <ul className="tags" aria-label={t.projects.language}>
          {tech.slice(0, 4).map((l) => <li key={l} className="tag muted">{l}</li>)}
        </ul>
      )}
      <div className="p-foot">
        <span className="p-date">{t.projects.updated} {formatDate(p.updatedAt, lang)}</span>
        <div className="p-links">
          <a className="p-link" href={p.url} target="_blank" rel="noopener noreferrer" aria-label={`${t.projects.repo}: ${p.name} (${t.platforms[p.platform]})`}>
            {t.projects.repo} <IconArrowUpRight className="flip-rtl" />
          </a>
          {p.demoUrl && (
            <a className="p-link" href={p.demoUrl} target="_blank" rel="noopener noreferrer" aria-label={`${t.projects.demo}: ${p.name}`}>
              {t.projects.demo} <IconArrowUpRight className="flip-rtl" />
            </a>
          )}
        </div>
      </div>
      {p.mirrors.length > 0 && (
        <div className="mirrors">
          <span>{t.projects.alsoOn}</span>
          {p.mirrors.map((m) => (
            <a key={m.url} href={m.url} target="_blank" rel="noopener noreferrer" aria-label={`${p.name} — ${t.platforms[m.platform]}`} title={t.platforms[m.platform]}>
              <BrandIcon id={m.platform} />
            </a>
          ))}
        </div>
      )}
    </article>
  );
}

export function Gallery({ data }: { data: ReturnType<typeof useProjects> }) {
  const { t, lang } = useI18n();
  const { state, reload } = data;
  const [q, setQ] = useState('');
  const [platform, setPlatform] = useState<Filter>('all');
  const [language, setLanguage] = useState('all');
  const [sort, setSort] = useState<'updated' | 'name'>('updated');
  const PAGE = 9;
  const [visible, setVisible] = useState(PAGE);
  useEffect(() => setVisible(PAGE), [q, platform, language, sort]);

  const projects = state.status === 'ready' ? state.index.projects : [];
  const languages = useMemo(() => {
    const m = new Map<string, number>();
    for (const p of projects) for (const l of p.languages) m.set(l, (m.get(l) || 0) + 1);
    return [...m.entries()].sort((a, b) => b[1] - a[1]).map(([k]) => k);
  }, [projects]);

  const filtered = useMemo(() => {
    const nq = normalize(q);
    const list = projects.filter((p) => {
      if (platform !== 'all' && !p.platforms.includes(platform)) return false;
      if (language !== 'all' && !p.languages.includes(language)) return false;
      if (nq) {
        const hay = normalize([p.name, p.name.replace(/[-_.]/g, ' '), p.description, ...Object.values(p.descriptions || {})].filter(Boolean).join(' '));
        if (!nq.split(' ').every((w) => hay.includes(w))) return false;
      }
      return true;
    });
    return list.sort((a, b) =>
      sort === 'name'
        ? a.name.localeCompare(b.name, lang)
        : (+b.featured - +a.featured) || +new Date(b.updatedAt) - +new Date(a.updatedAt),
    );
  }, [projects, q, platform, language, sort, lang]);

  const reset = () => { setQ(''); setPlatform('all'); setLanguage('all'); setSort('updated'); };
  const down = state.status === 'ready'
    ? PLATFORMS.filter((p) => state.index.sources?.[p]?.status === 'error')
    : [];

  return (
    <section id="projects" className="section" aria-labelledby="projects-title">
      <div className="container">
        <div className="section-head reveal">
          <h2 id="projects-title" className="section-title">{t.projects.title}</h2>
          <p className="section-sub">{t.projects.subtitle}</p>
        </div>

        <form className="toolbar" role="search" onSubmit={(e) => e.preventDefault()}>
          <div className="field field-search">
            <label htmlFor="p-search">{t.projects.search}</label>
            <div className="search-wrap">
              <IconSearch />
              <input id="p-search" className="input" type="search" value={q} onChange={(e) => setQ(e.target.value)} placeholder={t.projects.searchPlaceholder} autoComplete="off" />
            </div>
          </div>
          <div className="field field-platform">
            <span className="label" id="pf-label">{t.projects.platform}</span>
            <div className="chips" role="group" aria-labelledby="pf-label">
              {(['all', ...PLATFORMS] as Filter[]).map((f) => (
                <button key={f} type="button" className="chip" aria-pressed={platform === f} onClick={() => setPlatform(f)}>
                  {f !== 'all' && <BrandIcon id={f} />}
                  {f === 'all' ? t.projects.all : t.platforms[f]}
                </button>
              ))}
            </div>
          </div>
          <div className="field">
            <label htmlFor="p-lang">{t.projects.language}</label>
            <select id="p-lang" className="select" value={language} onChange={(e) => setLanguage(e.target.value)}>
              <option value="all">{t.projects.allLanguages}</option>
              {languages.map((l) => <option key={l} value={l}>{l}</option>)}
            </select>
          </div>
          <div className="field">
            <label htmlFor="p-sort">{t.projects.sort}</label>
            <select id="p-sort" className="select" value={sort} onChange={(e) => setSort(e.target.value as 'updated' | 'name')}>
              <option value="updated">{t.projects.sortUpdated}</option>
              <option value="name">{t.projects.sortName}</option>
            </select>
          </div>
        </form>

        {state.status === 'loading' && (
          <div aria-busy="true" aria-live="polite">
            <p className="sr-only">{t.projects.loading}</p>
            <div className="p-grid">{Array.from({ length: 6 }, (_, i) => <div key={i} className="skeleton" />)}</div>
          </div>
        )}

        {state.status === 'error' && (
          <div className="glass state" role="alert">
            <p>{t.projects.error}</p>
            <div className="links">
              {PROFILES.filter((p) => ['github', 'gitlab', 'codeberg'].includes(p.id)).map((p) => (
                <a key={p.id} className="btn btn-ghost btn-sm" href={p.url} target="_blank" rel="noopener noreferrer"><BrandIcon id={p.id} /> {p.name}</a>
              ))}
            </div>
            <button type="button" className="btn btn-primary btn-sm" onClick={reload}>{t.projects.retry}</button>
          </div>
        )}

        {state.status === 'ready' && (
          <>
            {down.map((p) => <p key={p} className="notice">{t.projects.sourceDown(t.platforms[p])}</p>)}
            <div className="gallery-meta">
              <span aria-live="polite">{t.projects.showing(Math.min(visible, filtered.length), filtered.length, projects.length)}</span>
              <span>{t.projects.syncedAt(formatDate(state.index.generatedAt, lang))}</span>
            </div>
            {filtered.length ? (
              <>
                <div className="p-grid">{filtered.slice(0, visible).map((p) => <ProjectCard key={p.id} p={p} />)}</div>
                {filtered.length > visible && (
                  <div style={{ display: 'flex', justifyContent: 'center', marginTop: '1.5rem' }}>
                    <button type="button" className="btn btn-ghost" onClick={() => setVisible((v) => v + PAGE)}>
                      {t.projects.more(Math.min(PAGE, filtered.length - visible))}
                    </button>
                  </div>
                )}
              </>
            ) : (
              <div className="glass state">
                <p>{t.projects.empty}</p>
                <button type="button" className="btn btn-ghost btn-sm" onClick={reset}>{t.projects.reset}</button>
              </div>
            )}
          </>
        )}
      </div>
    </section>
  );
}
