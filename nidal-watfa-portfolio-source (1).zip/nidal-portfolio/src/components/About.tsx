import { useState } from 'react';
import { useI18n } from '../i18n';

export function About() {
  const { t, lang } = useI18n();
  const [open, setOpen] = useState(false);
  const a = t.about;
  const tools = ['Termux', 'Acode', 'Git', { en: 'AI-assisted programming', ar: 'البرمجة بمساعدة الذكاء الاصطناعي', es: 'Programación asistida por IA' }[lang], 'Android'];
  return (
    <section id="about" className="section" aria-labelledby="about-title">
      <div className="container">
        <div className="about-grid">
          <div className="about-copy reveal">
            <span className="eyebrow">{a.label}</span>
            <h2 id="about-title" className="about-title">{a.title.split(' ').slice(0, -1).join(' ')} <em>{a.title.split(' ').slice(-1)}</em></h2>
            <p className="about-lead">{a.lead}</p>
            <p className="about-intro">{a.intro}</p>
            <div>
              <button type="button" className="btn btn-ghost" aria-expanded={open} aria-controls="full-story" onClick={() => setOpen((o) => !o)}>
                {open ? a.readLess : a.readMore}
              </button>
            </div>
          </div>
          <div className="about-visual reveal">
            <img src={`${import.meta.env.BASE_URL}assets/about-layers.webp`} width={760} height={1140} loading="lazy" decoding="async" alt={a.imgAlt} />
          </div>
        </div>

        <div id="full-story" className="story" hidden={!open}>
          <div className="roles">
            {a.roles.map((r) => (
              <article key={r.org} className="glass role">
                <div className="role-meta"><span className="role-period">{r.period}</span><span>{r.place}</span></div>
                <h3 dir="ltr" style={{ textAlign: 'start' }}>{r.org}</h3>
                <p className="role-title">{r.role}</p>
                <p>{r.text}</p>
              </article>
            ))}
          </div>
          <div className="story-row">
            <article className="glass story-block">
              <h3>{a.spanishTitle}</h3>
              <p>{a.spanishText}</p>
            </article>
            <article className="glass story-block">
              <h3>{a.phoneTitle}</h3>
              <p>{a.phoneText}</p>
              <div style={{ display: 'grid', gap: '.5rem', marginTop: '.4rem' }}>
                <span className="stack-label">{a.toolsLabel}</span>
                <ul className="tags tools">{tools.map((x) => <li key={x} className="tag">{x}</li>)}</ul>
              </div>
            </article>
          </div>
          <figure className="quote">
            <blockquote><span>“{a.quote}”</span></blockquote>
            <p>{a.statement}</p>
          </figure>
        </div>
      </div>
    </section>
  );
}
