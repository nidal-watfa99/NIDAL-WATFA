import { useId } from 'react';

/**
 * NW monogram — the N's right stem becomes the W's first stroke,
 * forming one continuous line. Designed to read at 24px and 400px.
 */
export const NW_PATH = 'M14 76 V24 L44 76 V24 L56 76 L68 40 L80 76 L92 24';

export function Logo({ size = 36, title = 'Nidal Watfa' }: { size?: number; title?: string }) {
  const id = useId().replace(/:/g, '');
  return (
    <svg width={size} height={size} viewBox="0 0 106 100" role="img" aria-label={title}>
      <defs>
        <linearGradient id={`lg-${id}`} x1="0" y1="0" x2="1" y2="1">
          <stop offset="0" stopColor="#FFFFFF" />
          <stop offset=".45" stopColor="#AEBBCD" />
          <stop offset=".7" stopColor="#69D5FF" />
          <stop offset="1" stopColor="#368BFF" />
        </linearGradient>
      </defs>
      <path d={NW_PATH} fill="none" stroke="#0b1220" strokeWidth="11" strokeLinejoin="miter" strokeMiterlimit={6} transform="translate(1.2 1.6)" />
      <path d={NW_PATH} fill="none" stroke={`url(#lg-${id})`} strokeWidth="9" strokeLinejoin="miter" strokeMiterlimit={6} strokeLinecap="square" />
    </svg>
  );
}
