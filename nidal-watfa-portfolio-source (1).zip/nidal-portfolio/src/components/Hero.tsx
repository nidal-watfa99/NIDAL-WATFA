import { useI18n } from '../i18n';
import { Emblem } from './Emblem';
import { IconArrowRight } from './Icons';

export function Hero() {
  const { t } = useI18n();
  return (
    <section id="home" className="hero" aria-labelledby="hero-title">
      <div className="container hero-grid">
        <div className="hero-copy">
          <span className="eyebrow">{t.hero.eyebrow}</span>
          <h1 id="hero-title" className="hero-title">
            <span className="w1">{t.hero.first}</span>
            <span className="w2">{t.hero.last}</span>
          </h1>
          <p className="hero-tagline">{t.hero.tagline}</p>
          <p className="hero-intro">{t.hero.intro}</p>
          <div className="hero-cta">
            <a className="btn btn-primary" href="#projects">
              {t.hero.explore} <IconArrowRight className="flip-rtl" />
            </a>
            <a className="btn btn-ghost" href="#contact">{t.hero.connect}</a>
          </div>
        </div>
        <div className="hero-visual">
          <Emblem label={t.hero.emblemAlt} />
        </div>
      </div>
    </section>
  );
}
