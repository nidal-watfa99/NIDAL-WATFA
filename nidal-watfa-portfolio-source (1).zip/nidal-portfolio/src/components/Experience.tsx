import { DESTINATIONS } from '../content/profile';
import { LAND_PATH, MAP_H, MAP_POINTS, MAP_W } from '../content/map';
import { useI18n } from '../i18n';

export function Experience() {
  const { t } = useI18n();
  const e = t.experience;
  const [bx, by] = MAP_POINTS.malabo;
  return (
    <section id="experience" className="section" aria-labelledby="exp-title">
      <div className="container exp-grid">
        <div className="exp-copy reveal">
          <span className="eyebrow">{e.label}</span>
          <h2 id="exp-title" className="section-title">{e.title}</h2>
          <p className="exp-range">{e.range}</p>
          <p style={{ color: 'var(--text-2)' }}>{e.text}</p>
          <ul className="dest-list">
            <li className="base">{e.base}</li>
            {DESTINATIONS.map((d) => <li key={d}>{t.destinations[d]}</li>)}
          </ul>
          <p className="exp-note">{e.note}</p>
        </div>
        <figure className="glass map reveal" style={{ margin: 0 }}>
          <svg viewBox={`0 0 ${MAP_W} ${MAP_H}`} role="img" aria-label={e.mapAlt}>
            <defs>
              <linearGradient id="routeGrad" x1="0" y1="1" x2="1" y2="0">
                <stop offset="0" stopColor="#368BFF" />
                <stop offset="1" stopColor="#875CFF" />
              </linearGradient>
            </defs>
            <path className="land" d={LAND_PATH} />
            {DESTINATIONS.map((d) => {
              const [x, y] = MAP_POINTS[d];
              const mx = (x + bx) / 2, my = Math.min(y, by) - 60;
              return <path key={d} className="route" d={`M${bx} ${by} Q${mx} ${my} ${x} ${y}`} />;
            })}
            {DESTINATIONS.map((d) => {
              const [x, y] = MAP_POINTS[d];
              return (
                <g key={d}>
                  <circle className="dot-halo" cx={x} cy={y} r="11" />
                  <circle className="dot" cx={x} cy={y} r="4.5" />
                </g>
              );
            })}
            <circle cx={bx} cy={by} r="20" fill="rgba(54,139,255,.18)" />
            <circle className="base-dot" cx={bx} cy={by} r="7" />
          </svg>
        </figure>
      </div>
    </section>
  );
}
