import { NW_PATH } from './Logo';

/** Large luminous hero emblem: metallic NW monogram, orbital rings and light trails. */
export function Emblem({ label }: { label: string }) {
  return (
    <svg className="emblem" viewBox="0 0 600 600" role="img" aria-label={label}>
      <defs>
        <radialGradient id="em-glow" cx="50%" cy="50%" r="50%">
          <stop offset="0" stopColor="#368BFF" stopOpacity=".42" />
          <stop offset=".45" stopColor="#875CFF" stopOpacity=".16" />
          <stop offset="1" stopColor="#05070C" stopOpacity="0" />
        </radialGradient>
        <radialGradient id="em-disc" cx="40%" cy="30%" r="75%">
          <stop offset="0" stopColor="#1c2840" />
          <stop offset=".6" stopColor="#0b111c" />
          <stop offset="1" stopColor="#05070C" />
        </radialGradient>
        <linearGradient id="em-metal" x1="0" y1="0" x2="1" y2="1">
          <stop offset="0" stopColor="#FFFFFF" />
          <stop offset=".28" stopColor="#D9E1EC" />
          <stop offset=".5" stopColor="#8F9DB2" />
          <stop offset=".66" stopColor="#E8EEF6" />
          <stop offset=".84" stopColor="#69D5FF" />
          <stop offset="1" stopColor="#368BFF" />
        </linearGradient>
        <linearGradient id="em-edge" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0" stopColor="#ffffff" stopOpacity=".9" />
          <stop offset="1" stopColor="#ffffff" stopOpacity="0" />
        </linearGradient>
        <linearGradient id="em-ring" x1="0" y1="0" x2="1" y2="0">
          <stop offset="0" stopColor="#69D5FF" stopOpacity="0" />
          <stop offset=".5" stopColor="#69D5FF" stopOpacity=".9" />
          <stop offset="1" stopColor="#875CFF" stopOpacity="0" />
        </linearGradient>
        <linearGradient id="em-trail" x1="0" y1="0" x2="1" y2="1">
          <stop offset="0" stopColor="#368BFF" stopOpacity="0" />
          <stop offset="1" stopColor="#69D5FF" stopOpacity="1" />
        </linearGradient>
        <filter id="em-blur" x="-50%" y="-50%" width="200%" height="200%"><feGaussianBlur stdDeviation="6" /></filter>
        <filter id="em-soft" x="-20%" y="-20%" width="140%" height="140%"><feGaussianBlur stdDeviation="2.2" /></filter>
      </defs>

      <circle cx="300" cy="300" r="300" fill="url(#em-glow)" className="pulse" />

      {/* orbital rings */}
      <g className="orbit-a" fill="none">
        <ellipse cx="300" cy="300" rx="262" ry="96" stroke="rgba(154,168,188,.22)" strokeWidth="1" transform="rotate(-22 300 300)" />
        <circle cx="542" cy="200" r="3" fill="#69D5FF" transform="rotate(-22 300 300)" />
      </g>
      <g className="orbit-b" fill="none">
        <ellipse cx="300" cy="300" rx="250" ry="120" stroke="rgba(135,92,255,.26)" strokeWidth="1" transform="rotate(28 300 300)" />
        <circle cx="60" cy="330" r="2.4" fill="#875CFF" transform="rotate(28 300 300)" />
      </g>
      <circle cx="300" cy="300" r="214" fill="none" stroke="rgba(154,168,188,.14)" strokeWidth="1" />
      <circle cx="300" cy="300" r="232" fill="none" stroke="rgba(54,139,255,.12)" strokeWidth="1" strokeDasharray="2 7" />

      {/* light trails */}
      <g className="trail">
        <circle cx="300" cy="300" r="214" fill="none" stroke="url(#em-trail)" strokeWidth="2" strokeDasharray="160 1185" strokeLinecap="round" />
        <circle cx="300" cy="300" r="214" fill="none" stroke="#69D5FF" strokeWidth="6" strokeDasharray="60 1285" strokeLinecap="round" filter="url(#em-blur)" opacity=".7" />
      </g>
      <g className="trail-2">
        <circle cx="300" cy="300" r="232" fill="none" stroke="#875CFF" strokeWidth="1.5" strokeDasharray="90 1368" strokeLinecap="round" opacity=".8" />
      </g>

      {/* disc */}
      <circle cx="300" cy="300" r="178" fill="url(#em-disc)" />
      <circle cx="300" cy="300" r="178" fill="none" stroke="url(#em-ring)" strokeWidth="1.5" />
      <circle cx="300" cy="300" r="170" fill="none" stroke="rgba(255,255,255,.06)" strokeWidth="1" />
      <path d="M150 220 A170 170 0 0 1 420 160" fill="none" stroke="url(#em-edge)" strokeWidth="1" opacity=".35" />

      {/* monogram: shadow, glow, metal, highlight */}
      <g transform="translate(300 300) scale(2.55) translate(-53 -50)">
        <path d={NW_PATH} fill="none" stroke="#368BFF" strokeWidth="9" strokeLinejoin="miter" strokeMiterlimit={6} opacity=".55" filter="url(#em-blur)" />
        <path d={NW_PATH} fill="none" stroke="#02040a" strokeWidth="10.5" strokeLinejoin="miter" strokeMiterlimit={6} transform="translate(1.2 1.8)" />
        <path d={NW_PATH} fill="none" stroke="url(#em-metal)" strokeWidth="8.5" strokeLinejoin="miter" strokeMiterlimit={6} strokeLinecap="square" />
        <path d={NW_PATH} fill="none" stroke="rgba(255,255,255,.7)" strokeWidth=".7" strokeLinejoin="miter" strokeMiterlimit={6} transform="translate(-1 -1.2)" filter="url(#em-soft)" />
      </g>
    </svg>
  );
}
