import { PROFILES, SITE_REPO } from '../content/profile';
import { useI18n } from '../i18n';
import { BrandIcon } from './Icons';

export function Footer() {
  const { t } = useI18n();
  return (
    <footer className="site-footer">
      <div className="container footer-inner">
        <p className="footer-word" aria-label="Nidal Watfa">NIDAL WATFA</p>
        <nav className="footer-links" aria-label="Profiles">
          {PROFILES.map((p) => (
            <a key={p.id} href={p.url} target="_blank" rel="noopener noreferrer me" aria-label={p.name} title={p.name}>
              <BrandIcon id={p.id} color="currentColor" />
            </a>
          ))}
        </nav>
        <div className="footer-small">
          <span>© {new Date().getFullYear()} Nidal Watfa</span>
          <span>{t.footer.rights}</span>
          {SITE_REPO && <a href={SITE_REPO} target="_blank" rel="noopener noreferrer">{t.footer.source}</a>}
        </div>
      </div>
    </footer>
  );
}
