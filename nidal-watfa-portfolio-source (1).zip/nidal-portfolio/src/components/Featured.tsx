import { FEATURED } from '../content/profile';
import { useI18n } from '../i18n';
import { BrandIcon, IconArrowRight, IconArrowUpRight } from './Icons';

function TechLines() {
  return (
    <svg className="tech-lines" viewBox="0 0 600 400" preserveAspectRatio="none" aria-hidden="true">
      <g fill="none" stroke="currentColor" strokeWidth=".6" opacity=".7">
        <path d="M0 330 H120 L150 300 H260" />
        <path d="M600 60 H480 L455 85 H360" />
        <path d="M600 350 H500 L470 320" />
        <path d="M30 0 V60 L60 90" />
      </g>
      <g fill="currentColor">
        <circle cx="260" cy="300" r="2.5" /><circle cx="360" cy="85" r="2.5" /><circle cx="470" cy="320" r="2.5" /><circle cx="60" cy="90" r="2.5" />
      </g>
    </svg>
  );
}

export function Featured() {
  const { t } = useI18n();
  return (
    <section id="featured" className="section" aria-labelledby="featured-title" style={{ paddingTop: 0 }}>
      <div className="container">
        <article className="glass featured reveal">
          <div className="featured-copy">
            <span className="eyebrow">{t.featured.label}</span>
            <h2 id="featured-title" className="featured-name">{FEATURED.name}</h2>
            <p className="featured-desc">{t.featured.description}</p>
            <p className="featured-detail">{t.featured.detail}</p>
            <div style={{ display: 'grid', gap: '.5rem' }}>
              <span className="stack-label">{t.featured.stackLabel}</span>
              <ul className="tags">{FEATURED.tags.map((tag) => <li key={tag} className="tag">{tag}</li>)}</ul>
            </div>
            <div className="featured-actions">
              <a className="btn btn-primary" href={FEATURED.repo} target="_blank" rel="noopener noreferrer">
                <BrandIcon id="github" color="#fff" /> {t.featured.view}
              </a>
              <a className="btn btn-ghost" href="#projects">{t.featured.all} <IconArrowRight className="flip-rtl" /></a>
            </div>
          </div>
          <figure className="featured-visual" style={{ margin: 0 }}>
            <TechLines />
            <div className="device">
              <div className="device-bar" aria-hidden="true"><i /><i /><i /></div>
              <img src={`${import.meta.env.BASE_URL}${FEATURED.preview}`} width={1200} height={750} loading="lazy" decoding="async"
                alt="Veyra AI dashboard: command overview with AI personnel cards, metrics and navigation sidebar" />
            </div>
            <figcaption className="caption">
              {t.featured.caption}{' '}
              <a className="caption-link" href={FEATURED.demo} target="_blank" rel="noopener noreferrer">
                {t.featured.demo} <IconArrowUpRight className="flip-rtl" />
              </a>
            </figcaption>
          </figure>
        </article>
      </div>
    </section>
  );
}
