import { useEffect, useMemo, useRef, useState, type FormEvent } from 'react';
import { answer, type Reply, type Strings } from '../assistant/engine';
import type { L } from '../assistant/knowledge';
import en from '../i18n/en';
import ar from '../i18n/ar';
import es from '../i18n/es';
import { formatDate, useI18n } from '../i18n';
import type { useProjects } from '../lib/projects';
import { IconChat, IconClose, IconSend } from './Icons';

type Msg = { id: number; from: 'user' | 'bot'; text: string; reply?: Reply };
const DICTS = { en, ar, es };

export function Assistant({ data, open, setOpen }: { data: ReturnType<typeof useProjects>; open: boolean; setOpen: (o: boolean) => void }) {
  const { t, lang } = useI18n();
  const [msgs, setMsgs] = useState<Msg[]>([]);
  const [input, setInput] = useState('');
  const [busy, setBusy] = useState(false);
  const logRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLInputElement>(null);
  const fabRef = useRef<HTMLButtonElement>(null);
  const nextId = useRef(1);

  const strings = useMemo(() => {
    const mk = (l: L): Strings => ({
      unknown: DICTS[l].assistant.unknown,
      projectsFound: DICTS[l].assistant.projectsFound,
      projectCount: DICTS[l].assistant.projectCount,
      latest: DICTS[l].assistant.latest,
      formatDate: (iso) => formatDate(iso, l),
    });
    return { en: mk('en'), ar: mk('ar'), es: mk('es') };
  }, []);

  useEffect(() => {
    if (open) setTimeout(() => inputRef.current?.focus(), 30);
  }, [open]);

  useEffect(() => {
    logRef.current?.scrollTo({ top: logRef.current.scrollHeight, behavior: 'smooth' });
  }, [msgs, busy]);

  useEffect(() => {
    if (!open) return;
    const onKey = (e: KeyboardEvent) => { if (e.key === 'Escape') { setOpen(false); fabRef.current?.focus(); } };
    document.addEventListener('keydown', onKey);
    return () => document.removeEventListener('keydown', onKey);
  }, [open, setOpen]);

  const ask = (q: string) => {
    const text = q.trim().slice(0, 300);
    if (!text || busy) return;
    setMsgs((m) => [...m, { id: nextId.current++, from: 'user', text }]);
    setInput('');
    setBusy(true);
    // Short delay keeps the exchange readable; the search itself is synchronous and instant.
    setTimeout(() => {
      try {
        const index = data.state.status === 'ready' ? data.state.index : null;
        const reply = answer(text, lang, index, strings);
        let out = reply.text;
        if (!index && reply.kind !== 'kb') out += `\n\n${DICTS[reply.lang].assistant.loadingProjects}`;
        setMsgs((m) => [...m, { id: nextId.current++, from: 'bot', text: out, reply }]);
      } catch {
        setMsgs((m) => [...m, { id: nextId.current++, from: 'bot', text: t.assistant.error }]);
      } finally {
        setBusy(false);
      }
    }, 260);
  };

  const submit = (e: FormEvent) => { e.preventDefault(); ask(input); };
  const go = (href: string) => {
    if (href.startsWith('#')) {
      if (window.matchMedia('(max-width: 640px)').matches) setOpen(false);
      if (href === '#about' || href === '#featured') document.getElementById('full-story')?.removeAttribute('hidden');
    }
  };

  return (
    <>
      {!open && (
        <button ref={fabRef} type="button" className="assistant-fab" aria-haspopup="dialog" aria-expanded={open} onClick={() => setOpen(true)}>
          <span className="orb"><IconChat /></span>
          <span className="label">{t.assistant.open}</span>
          <span className="sr-only">{t.assistant.open}</span>
        </button>
      )}
      {open && (
        <div className="chat" role="dialog" aria-modal="false" aria-labelledby="chat-title">
          <div className="chat-head">
            <span className="orb" aria-hidden="true" />
            <div>
              <h2 id="chat-title">{t.assistant.title}</h2>
              <p>{t.assistant.status}</p>
            </div>
            <button type="button" className="icon-btn" aria-label={t.assistant.close} onClick={() => { setOpen(false); setTimeout(() => fabRef.current?.focus(), 30); }}>
              <IconClose />
            </button>
          </div>
          <div className="chat-log" ref={logRef} aria-live="polite" aria-relevant="additions">
            <div className="msg bot">{t.assistant.greeting}</div>
            {msgs.map((m) => {
              const rl = m.reply?.lang ?? lang;
              return (
                <div key={m.id} className={`msg ${m.from}`} dir="auto" lang={m.from === 'bot' ? rl : undefined}>
                  <span className="sr-only">{m.from === 'user' ? t.assistant.you : t.assistant.bot}: </span>
                  {m.text}
                  {m.reply && m.reply.projects.length > 0 && (
                    <div className="msg-projects">
                      {m.reply.projects.map((p) => (
                        <a key={p.id} href={p.url} target="_blank" rel="noopener noreferrer">
                          <strong>{p.name}</strong>
                          <span>{DICTS[rl].platforms[p.platform]} · {(p.tags?.length ? p.tags : p.languages).slice(0, 3).join(', ') || '—'} · {formatDate(p.updatedAt, rl)}</span>
                        </a>
                      ))}
                    </div>
                  )}
                  {m.reply && m.reply.links.length > 0 && (
                    <div className="msg-links">
                      {m.reply.links.map((l) => (
                        <a key={l.href} href={l.href} onClick={() => go(l.href)} {...(l.href.startsWith('#') || l.href.startsWith('mailto:') ? {} : { target: '_blank', rel: 'noopener noreferrer' })}>
                          {l.label[rl]}
                        </a>
                      ))}
                    </div>
                  )}
                </div>
              );
            })}
            {busy && <div className="msg bot typing" aria-label="…"><i /><i /><i /></div>}
          </div>
          {msgs.length === 0 && (
            <div className="suggest">
              {t.assistant.suggestions.map((s) => <button key={s} type="button" onClick={() => ask(s)}>{s}</button>)}
            </div>
          )}
          <form className="chat-form" onSubmit={submit}>
            <label htmlFor="chat-input" className="sr-only">{t.assistant.placeholder}</label>
            <input id="chat-input" ref={inputRef} className="input" value={input} onChange={(e) => setInput(e.target.value)} placeholder={t.assistant.placeholder} maxLength={300} autoComplete="off" dir="auto" />
            <button type="submit" className="send" disabled={!input.trim() || busy} aria-label={t.assistant.send}><IconSend /></button>
          </form>
          <p className="chat-foot">{t.assistant.disclaimer}</p>
        </div>
      )}
    </>
  );
}
