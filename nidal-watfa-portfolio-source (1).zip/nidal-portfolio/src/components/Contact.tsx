import { useState, type FormEvent } from 'react';
import { EMAIL } from '../content/profile';
import { useI18n } from '../i18n';
import { IconCopy, IconMail } from './Icons';

export function Contact() {
  const { t } = useI18n();
  const c = t.contact;
  const [status, setStatus] = useState('');
  const [name, setName] = useState('');
  const [msg, setMsg] = useState('');

  const copy = async () => {
    try {
      await navigator.clipboard.writeText(EMAIL);
      setStatus(c.copied);
    } catch {
      setStatus(c.copyFail);
    }
  };

  const submit = (e: FormEvent) => {
    e.preventDefault();
    if (!name.trim() || !msg.trim()) { setStatus(c.required); return; }
    const subject = encodeURIComponent(`Portfolio — ${name.trim()}`);
    const body = encodeURIComponent(`${msg.trim()}\n\n— ${name.trim()}`);
    window.location.href = `mailto:${EMAIL}?subject=${subject}&body=${body}`;
    setStatus(c.opened);
  };

  return (
    <section id="contact" className="section" aria-labelledby="contact-title">
      <div className="container">
        <div className="glass contact-card reveal">
          <div className="contact-copy">
            <span className="eyebrow">{c.label}</span>
            <h2 id="contact-title" className="section-title">{c.title}</h2>
            <p style={{ color: 'var(--text-2)' }}>{c.text}</p>
            <a className="email-link" href={`mailto:${EMAIL}`}>{EMAIL}</a>
            <div className="contact-actions">
              <a className="btn btn-primary" href={`mailto:${EMAIL}`}><IconMail /> {c.emailCta}</a>
              <button type="button" className="btn btn-ghost" onClick={copy}><IconCopy /> {c.copy}</button>
            </div>
            <p className="status-msg" role="status" aria-live="polite">{status}</p>
          </div>
          <form className="contact-form" onSubmit={submit} noValidate>
            <h3>{c.formTitle}</h3>
            <div className="field">
              <label htmlFor="c-name">{c.name}</label>
              <input id="c-name" className="input" value={name} onChange={(e) => setName(e.target.value)} autoComplete="name" required />
            </div>
            <div className="field">
              <label htmlFor="c-msg">{c.message}</label>
              <textarea id="c-msg" className="input" value={msg} onChange={(e) => setMsg(e.target.value)} required dir="auto" />
            </div>
            <button type="submit" className="btn btn-primary" style={{ justifySelf: 'start' }}><IconMail /> {c.send}</button>
            <p className="form-note">{c.formNote}</p>
          </form>
        </div>
      </div>
    </section>
  );
}
