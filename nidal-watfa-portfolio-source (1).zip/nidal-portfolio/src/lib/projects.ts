import { useCallback, useEffect, useState } from 'react';

export type SourcePlatform = 'github' | 'gitlab' | 'codeberg';

export interface Project {
  id: string;
  name: string;
  platform: SourcePlatform;
  url: string;
  description: string | null;
  descriptions?: Partial<Record<'en' | 'ar' | 'es', string>>;
  languages: string[];
  tags?: string[];
  topics: string[];
  updatedAt: string;
  createdAt: string | null;
  status: 'active' | 'archived';
  demoUrl: string | null;
  previewImage: string | null;
  featured: boolean;
  mirrors: { platform: SourcePlatform; url: string }[];
  platforms: SourcePlatform[];
}

export interface ProjectIndex {
  schemaVersion: number;
  generatedAt: string;
  sources: Record<SourcePlatform, { status: 'ok' | 'error'; count: number; syncedAt: string | null; error?: string }>;
  count: number;
  projects: Project[];
}

export type LoadState =
  | { status: 'loading' }
  | { status: 'error'; message: string }
  | { status: 'ready'; index: ProjectIndex };

let cache: Promise<ProjectIndex> | null = null;

export function loadIndex(force = false): Promise<ProjectIndex> {
  if (!cache || force) {
    cache = fetch(`${import.meta.env.BASE_URL}data/projects.json`, { cache: force ? 'reload' : 'default' })
      .then((r) => {
        if (!r.ok) throw new Error(`HTTP ${r.status}`);
        return r.json();
      })
      .then((j: ProjectIndex) => {
        if (!j || !Array.isArray(j.projects)) throw new Error('Invalid index');
        return j;
      })
      .catch((e) => {
        cache = null;
        throw e;
      });
  }
  return cache;
}

export function useProjects() {
  const [state, setState] = useState<LoadState>({ status: 'loading' });
  const load = useCallback((force = false) => {
    setState({ status: 'loading' });
    loadIndex(force)
      .then((index) => setState({ status: 'ready', index }))
      .catch((e) => setState({ status: 'error', message: String(e?.message || e) }));
  }, []);
  useEffect(() => load(), [load]);
  return { state, reload: () => load(true) };
}

/** Verified technology labels for a project: curated tags first, else languages from the APIs. */
export const techOf = (p: Project) => (p.tags && p.tags.length ? p.tags : p.languages);
