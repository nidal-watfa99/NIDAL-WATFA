/**
 * Structured, verified knowledge base for the local site assistant.
 * Every answer here must be supported by information supplied by Nidal
 * or verified from his public repositories. Add new entries freely —
 * the engine picks them up automatically.
 */
import { EMAIL, FEATURED, PROFILES } from '../content/profile';

export type L = 'en' | 'ar' | 'es';
export interface KBLink { label: Record<L, string>; href: string; }
export interface KBEntry {
  id: string;
  /** keywords per language; multi-word phrases allowed. Matching is accent/diacritic-insensitive. */
  keywords: Record<L, string[]>;
  answer: Record<L, string>;
  links?: KBLink[];
  /** extra weight for very specific entries */
  boost?: number;
}

const sec = (id: string, en: string, ar: string, es: string): KBLink => ({ label: { en, ar, es }, href: `#${id}` });
const prof = (id: string): KBLink => {
  const p = PROFILES.find((x) => x.id === id)!;
  return { label: { en: p.name, ar: p.name, es: p.name }, href: p.url };
};

export const KB: KBEntry[] = [
  {
    id: 'who',
    keywords: {
      en: ['who', 'nidal', 'watfa', 'about', 'yourself', 'background', 'introduce', 'bio', 'developer'],
      ar: ['من', 'نضال', 'وطفه', 'نبذه', 'تعريف', 'خلفيه', 'سيره', 'مطور'],
      es: ['quien', 'nidal', 'watfa', 'sobre', 'biografia', 'trayectoria', 'presentacion', 'desarrollador'],
    },
    answer: {
      en: 'Nidal Watfa is a self-taught developer whose experience combines international executive management, business operations, independent learning, and software development. He spent 1994–2010 working abroad, mostly in Equatorial Guinea, and today builds web projects primarily from an Android phone.',
      ar: 'نضال وطفة مطوّر علّم نفسه بنفسه، تجمع خبرته بين الإدارة التنفيذية الدولية وتشغيل الأعمال والتعلّم الذاتي وتطوير البرمجيات. عمل في الخارج بين 1994 و2010، معظمها في غينيا الاستوائية، ويبني اليوم مشاريع الويب أساساً من هاتف أندرويد.',
      es: 'Nidal Watfa es un desarrollador autodidacta cuya experiencia combina dirección ejecutiva internacional, operaciones empresariales, aprendizaje independiente y desarrollo de software. Trabajó en el extranjero entre 1994 y 2010, sobre todo en Guinea Ecuatorial, y hoy desarrolla proyectos web principalmente desde un teléfono Android.',
    },
    links: [sec('about', 'About section', 'قسم من أنا', 'Sección Sobre mí')],
  },
  {
    id: 'bisila',
    boost: 1,
    keywords: {
      en: ['bisila', 'palace', 'hotel', 'hospitality', 'malabo', 'executive management', 'administration'],
      ar: ['بيسيلا', 'bisila', 'فندق', 'ضيافه', 'مالابو', 'الاداره التنفيذيه', 'اداره'],
      es: ['bisila', 'palace', 'hotel', 'hosteleria', 'malabo', 'direccion ejecutiva', 'administracion'],
    },
    answer: {
      en: 'Nidal worked for five years in administrative and executive management at Bisila Palace in Malabo, Equatorial Guinea — a hotel near the roundabout serving Malabo International Airport. The experience shaped his understanding of administration, operational coordination, and management in an international hospitality environment.',
      ar: 'عمل نضال خمس سنوات في الإدارة الإدارية والتنفيذية في فندق Bisila Palace في مالابو بغينيا الاستوائية، القريب من الدوّار المؤدي إلى مطار مالابو الدولي. أسهمت التجربة في فهمه للإدارة والتنسيق التشغيلي والعمل في بيئة ضيافة دولية.',
      es: 'Nidal trabajó cinco años en dirección administrativa y ejecutiva en Bisila Palace, en Malabo (Guinea Ecuatorial), un hotel cerca de la rotonda que da acceso al Aeropuerto Internacional de Malabo. Esa etapa formó su comprensión de la administración, la coordinación operativa y la gestión en un entorno hotelero internacional.',
    },
    links: [sec('about', 'Professional story', 'القصة المهنية', 'Historia profesional')],
  },
  {
    id: 'riomuni',
    boost: 1,
    keywords: {
      en: ['rio muni', 'timberland', 'timber', 'wood', 'export', 'trade', 'manager'],
      ar: ['ريو موني', 'rio muni', 'تيمبرلاند', 'خشب', 'اخشاب', 'تصدير', 'تجاره', 'مدير'],
      es: ['rio muni', 'timberland', 'madera', 'exportacion', 'comercio', 'gerente'],
    },
    answer: {
      en: 'For seven years Nidal was a manager at Rio Muni Timberland, a company specialising in tropical timber production and the export of raw timber. Products were identified and traded according to internationally recognised specifications and standards, supplying markets in Asia, Europe, and the Middle East.',
      ar: 'عمل نضال سبع سنوات مديراً في Rio Muni Timberland، وهي شركة متخصصة في إنتاج الأخشاب الاستوائية وتصدير الأخشاب الخام. كانت المنتجات تُعرَّف وتُتداول وفق مواصفات ومعايير معترف بها دولياً، وتُورَّد إلى أسواق آسيا وأوروبا والشرق الأوسط.',
      es: 'Durante siete años Nidal fue gerente en Rio Muni Timberland, empresa especializada en la producción de madera tropical y la exportación de madera en bruto. Los productos se identificaban y comercializaban según especificaciones y normas reconocidas internacionalmente, con destino a Asia, Europa y Oriente Medio.',
    },
    links: [sec('about', 'Professional story', 'القصة المهنية', 'Historia profesional')],
  },
  {
    id: 'work',
    keywords: {
      en: ['work', 'worked', 'job', 'jobs', 'experience', 'career', 'employment', 'companies'],
      ar: ['عمل', 'اين عمل', 'وظيفه', 'خبره', 'خبرات', 'مسيره', 'شركات'],
      es: ['trabajo', 'trabajo', 'trabajó', 'experiencia', 'carrera', 'empleo', 'empresas', 'donde trabajo'],
    },
    answer: {
      en: 'Nidal’s main professional roles were five years in administrative and executive management at Bisila Palace (Malabo, Equatorial Guinea) and seven years as a manager at Rio Muni Timberland, a tropical-timber production and export company. He now focuses on software development.',
      ar: 'أبرز محطات نضال المهنية: خمس سنوات في الإدارة الإدارية والتنفيذية في Bisila Palace (مالابو، غينيا الاستوائية)، وسبع سنوات مديراً في Rio Muni Timberland لإنتاج الأخشاب الاستوائية وتصديرها. وهو يركّز اليوم على تطوير البرمجيات.',
      es: 'Sus principales puestos fueron cinco años en dirección administrativa y ejecutiva en Bisila Palace (Malabo, Guinea Ecuatorial) y siete años como gerente en Rio Muni Timberland, empresa de producción y exportación de madera tropical. Hoy se centra en el desarrollo de software.',
    },
    links: [sec('about', 'Professional story', 'القصة المهنية', 'Historia profesional')],
  },
  {
    id: 'travel',
    keywords: {
      en: ['international', 'abroad', 'travel', 'countries', 'country', 'destinations', 'paris', 'france', 'netherlands', 'egypt', 'ethiopia', 'cameroon', 'gabon', 'morocco', 'lebanon', '1994', '2010', 'equatorial guinea'],
      ar: ['دولي', 'الخارج', 'سفر', 'دول', 'بلدان', 'وجهات', 'باريس', 'فرنسا', 'هولندا', 'مصر', 'اثيوبيا', 'الكاميرون', 'الغابون', 'المغرب', 'لبنان', '1994', '2010', 'غينيا'],
      es: ['internacional', 'extranjero', 'viajes', 'paises', 'destinos', 'paris', 'francia', 'paises bajos', 'egipto', 'etiopia', 'camerun', 'gabon', 'marruecos', 'libano', '1994', '2010', 'guinea'],
    },
    answer: {
      en: 'His overseas professional journey ran from 3 July 1994 to his return home on 3 July 2010, based mainly in Equatorial Guinea. Work and work-related travel took him to destinations including Paris (France), the Netherlands, Spain, Egypt, Ethiopia, Cameroon, Gabon, Morocco, and Lebanon. These are places reached through work — not all places he lived.',
      ar: 'امتدت رحلته المهنية خارج الوطن من 3 تموز 1994 حتى عودته في 3 تموز 2010، وكانت غينيا الاستوائية مقرّه الأساسي. قادته الأعمال والأسفار المرتبطة بها إلى وجهات منها باريس (فرنسا) وهولندا وإسبانيا ومصر وإثيوبيا والكاميرون والغابون والمغرب ولبنان. هي وجهات بلغها بحكم العمل، لا أماكن إقامة جميعها.',
      es: 'Su trayectoria en el extranjero fue del 3 de julio de 1994 a su regreso el 3 de julio de 2010, con base principal en Guinea Ecuatorial. El trabajo y los viajes relacionados lo llevaron a destinos como París (Francia), Países Bajos, España, Egipto, Etiopía, Camerún, Gabón, Marruecos y Líbano. Son lugares visitados por trabajo, no todos lugares de residencia.',
    },
    links: [sec('experience', 'International experience', 'الخبرة الدولية', 'Experiencia internacional')],
  },
  {
    id: 'spanish',
    boost: 1,
    keywords: {
      en: ['spanish', 'language', 'languages', 'speak', 'speaks', 'fluent', 'arabic'],
      ar: ['الاسبانيه', 'اسباني', 'اسبانيه', 'لغه', 'لغات', 'يتكلم', 'يتحدث', 'العربيه'],
      es: ['espanol', 'idioma', 'idiomas', 'habla', 'lengua', 'arabe'],
    },
    answer: {
      en: 'Nidal learned Spanish independently through immersion — workplace communication and everyday professional interactions in a Spanish-speaking environment in Equatorial Guinea, not formal schooling. He has a good working command of Spanish. Most of his project descriptions are written in Arabic, and this website is available in Arabic, English, and Spanish.',
      ar: 'تعلّم نضال الإسبانية ذاتياً بالممارسة — التواصل في العمل والتعاملات المهنية اليومية في بيئة ناطقة بالإسبانية في غينيا الاستوائية، لا عبر الدراسة النظامية. ويتقنها إتقاناً جيداً للعمل. معظم أوصاف مشاريعه مكتوبة بالعربية، وهذا الموقع متاح بالعربية والإنجليزية والإسبانية.',
      es: 'Nidal aprendió español de forma independiente, por inmersión: la comunicación en el trabajo y el trato profesional diario en un entorno hispanohablante en Guinea Ecuatorial, no en la escuela. Tiene un buen dominio profesional del idioma. La mayoría de las descripciones de sus proyectos están en árabe, y este sitio está disponible en árabe, inglés y español.',
    },
    links: [sec('about', 'About section', 'قسم من أنا', 'Sección Sobre mí')],
  },
  {
    id: 'phone',
    boost: 1,
    keywords: {
      en: ['phone', 'smartphone', 'android', 'mobile', 'computer', 'laptop', 'pc', 'termux', 'acode', 'tools', 'setup', 'workflow', 'how does he code', 'without a computer'],
      ar: ['هاتف', 'جوال', 'موبايل', 'اندرويد', 'حاسوب', 'كمبيوتر', 'لابتوب', 'termux', 'تيرمكس', 'acode', 'ادوات', 'يبرمج', 'بدون حاسوب'],
      es: ['telefono', 'movil', 'android', 'smartphone', 'ordenador', 'computadora', 'portatil', 'termux', 'acode', 'herramientas', 'programa', 'sin ordenador'],
    },
    answer: {
      en: 'Nidal develops primarily from an Android smartphone. His environment includes Termux (a Linux terminal for Android), Acode (a code editor for Android), AI-assisted programming tools, and Git-based workflows. He does not currently own a computer because of unemployment and financial hardship. In his words: “Limited resources should not define the limits of an idea.”',
      ar: 'يطوّر نضال أساساً من هاتف أندرويد. تشمل بيئة عمله Termux (طرفية لينكس على أندرويد) وAcode (محرّر شيفرة لأندرويد) وأدوات البرمجة بمساعدة الذكاء الاصطناعي وسير عمل قائم على Git. لا يملك حاسوباً حالياً بسبب البطالة والضائقة المالية. وكما يقول: «الموارد المحدودة لا ينبغي أن تحدّد حدود الفكرة».',
      es: 'Nidal desarrolla principalmente desde un smartphone Android. Su entorno incluye Termux (terminal Linux para Android), Acode (editor de código para Android), herramientas de programación asistida por IA y flujos de trabajo con Git. Actualmente no tiene ordenador por el desempleo y las dificultades económicas. En sus palabras: «Los recursos limitados no deberían definir los límites de una idea».',
    },
    links: [sec('about', 'About section', 'قسم من أنا', 'Sección Sobre mí')],
  },
  {
    id: 'constraints',
    keywords: {
      en: ['domain', 'hosting', 'paid', 'payment', 'sanctions', 'bank', 'banking', 'money', 'challenges', 'barriers', 'support'],
      ar: ['نطاق', 'دومين', 'استضافه', 'مدفوع', 'دفع', 'عقوبات', 'بنك', 'مصرف', 'تحديات', 'صعوبات', 'دعم'],
      es: ['dominio', 'alojamiento', 'hosting', 'pago', 'sanciones', 'banco', 'dinero', 'retos', 'barreras', 'apoyo'],
    },
    answer: {
      en: 'Economic instability, international sanctions affecting his local environment, restricted access to some development and hosting services, and the lack of practical banking and payment options make it hard for Nidal to buy a domain or paid services. That is why this site is built to run on free static hosting. For collaboration or support, email is the best channel.',
      ar: 'عدم الاستقرار الاقتصادي، والعقوبات الدولية التي تؤثّر في بيئته المحلية، وتقييد الوصول إلى بعض خدمات التطوير والاستضافة، وغياب وسائل مصرفية ودفع عملية، كلها تصعّب على نضال شراء نطاق أو خدمات مدفوعة. لهذا بُني الموقع ليعمل على استضافة ثابتة مجانية. وللتعاون أو الدعم، البريد الإلكتروني هو أفضل وسيلة.',
      es: 'La inestabilidad económica, las sanciones internacionales que afectan a su entorno, el acceso restringido a algunos servicios de desarrollo y alojamiento y la falta de opciones bancarias y de pago prácticas dificultan que Nidal compre un dominio o servicios de pago. Por eso este sitio funciona en alojamiento estático gratuito. Para colaborar o apoyar, el correo es el mejor canal.',
    },
    links: [sec('contact', 'Contact', 'تواصل', 'Contacto')],
  },
  {
    id: 'veyra',
    boost: 3,
    keywords: {
      en: ['veyra', 'featured', 'ai employees', 'autonomous'],
      ar: ['veyra', 'فيرا', 'فيرا', 'المميز', 'موظفين افتراضيين'],
      es: ['veyra', 'destacado', 'empleados autonomos'],
    },
    answer: {
      en: `Veyra AI is Nidal’s featured project: an AI-powered application designed to make digital tasks simpler, faster, and smarter. According to its repository it is a platform for autonomous AI employees handling conversations, appointments, and lead follow-ups, built with ${FEATURED.tags.join(', ')}, with Arabic RTL and English interfaces and support for Gemini, Groq, Cerebras, and OpenRouter. The GitHub Pages demo shows the interface with sample data; the full API needs a Node.js host.`,
      ar: `Veyra AI هو المشروع المميّز لنضال: تطبيق مدعوم بالذكاء الاصطناعي صُمّم لجعل المهام الرقمية أبسط وأسرع وأذكى. وبحسب مستودعه، هو منصة لموظفين افتراضيين بالذكاء الاصطناعي يتولّون المحادثات والمواعيد ومتابعة العملاء، مبني بـ ${FEATURED.tags.join('، ')}، بواجهتين عربية وإنجليزية ودعم Gemini وGroq وCerebras وOpenRouter. العرض على GitHub Pages يُظهر الواجهة ببيانات تجريبية، أما الواجهة البرمجية الكاملة فتحتاج خادم Node.js.`,
      es: `Veyra AI es el proyecto destacado de Nidal: una aplicación impulsada por IA diseñada para hacer las tareas digitales más simples, rápidas e inteligentes. Según su repositorio, es una plataforma de empleados autónomos con IA que gestionan conversaciones, citas y seguimiento de clientes, construida con ${FEATURED.tags.join(', ')}, con interfaz en árabe (RTL) e inglés y soporte para Gemini, Groq, Cerebras y OpenRouter. La demo en GitHub Pages muestra la interfaz con datos de ejemplo; la API completa necesita un servidor Node.js.`,
    },
    links: [
      { label: { en: 'Veyra AI repository', ar: 'مستودع Veyra AI', es: 'Repositorio de Veyra AI' }, href: FEATURED.repo },
      { label: { en: 'Live demo', ar: 'العرض المباشر', es: 'Demo en vivo' }, href: FEATURED.demo },
      sec('featured', 'Featured project', 'المشروع المميّز', 'Proyecto destacado'),
    ],
  },
  {
    id: 'contact',
    boost: 1,
    keywords: {
      en: ['contact', 'email', 'mail', 'reach', 'hire', 'message', 'collaborate', 'collaboration', 'get in touch'],
      ar: ['تواصل', 'التواصل', 'اتواصل', 'بريد', 'ايميل', 'راسل', 'مراسله', 'توظيف', 'تعاون', 'رساله'],
      es: ['contacto', 'contactar', 'contactarlo', 'correo', 'email', 'escribir', 'contratar', 'mensaje', 'colaborar'],
    },
    answer: {
      en: `The most reliable way to reach Nidal is email: ${EMAIL}. You can also find him on LinkedIn and X.`,
      ar: `أضمن وسيلة للتواصل مع نضال هي البريد الإلكتروني: ${EMAIL}. ويمكنك أيضاً إيجاده على LinkedIn وX.`,
      es: `La forma más fiable de contactar con Nidal es el correo: ${EMAIL}. También está en LinkedIn y X.`,
    },
    links: [
      { label: { en: `Email ${EMAIL}`, ar: `راسل ${EMAIL}`, es: `Escribir a ${EMAIL}` }, href: `mailto:${EMAIL}` },
      prof('linkedin'),
      sec('contact', 'Contact section', 'قسم التواصل', 'Sección de contacto'),
    ],
  },
  {
    id: 'profiles',
    keywords: {
      en: ['profiles', 'platforms', 'accounts', 'social', 'links', 'find him', 'online'],
      ar: ['حسابات', 'منصات', 'روابط', 'تواصل اجتماعي', 'الملفات الشخصيه'],
      es: ['perfiles', 'plataformas', 'cuentas', 'redes', 'enlaces'],
    },
    answer: {
      en: 'Nidal is on GitHub (nidal-watfa99), GitLab (nidalwatfa), Codeberg (nidalwatfa), ORCID (0009-0003-2462-6630), LinkedIn, and X (@NidalWatfa12501).',
      ar: 'نضال موجود على GitHub ‏(nidal-watfa99) وGitLab ‏(nidalwatfa) وCodeberg ‏(nidalwatfa) وORCID ‏(0009-0003-2462-6630) وLinkedIn وX ‏(@NidalWatfa12501).',
      es: 'Nidal está en GitHub (nidal-watfa99), GitLab (nidalwatfa), Codeberg (nidalwatfa), ORCID (0009-0003-2462-6630), LinkedIn y X (@NidalWatfa12501).',
    },
    links: [sec('ecosystem', 'Digital ecosystem', 'المنظومة الرقمية', 'Ecosistema digital')],
  },
  ...(['github', 'gitlab', 'codeberg', 'orcid', 'linkedin', 'x'] as const).map((id): KBEntry => {
    const p = PROFILES.find((x) => x.id === id)!;
    const extra: Record<string, Record<L, string[]>> = {
      github: { en: ['github'], ar: ['github', 'جيت هب', 'جيتهب'], es: ['github'] },
      gitlab: { en: ['gitlab'], ar: ['gitlab', 'جيت لاب'], es: ['gitlab'] },
      codeberg: { en: ['codeberg'], ar: ['codeberg', 'كودبيرغ'], es: ['codeberg'] },
      orcid: { en: ['orcid', 'research', 'scholarly', 'publications'], ar: ['orcid', 'اوركيد', 'بحث', 'منشورات'], es: ['orcid', 'investigacion', 'publicaciones'] },
      linkedin: { en: ['linkedin'], ar: ['linkedin', 'لينكدان', 'لينكد ان'], es: ['linkedin'] },
      x: { en: ['twitter', 'x.com', 'tweets'], ar: ['تويتر', 'اكس', 'x.com'], es: ['twitter', 'x.com'] },
    };
    return {
      id: `profile-${id}`,
      boost: 2,
      keywords: extra[id],
      answer: {
        en: `Nidal’s ${p.name} profile: ${p.url}`,
        ar: `حساب نضال على ${p.name}: ${p.url}`,
        es: `Perfil de Nidal en ${p.name}: ${p.url}`,
      },
      links: [prof(id)],
    };
  }),
  {
    id: 'site',
    keywords: {
      en: ['this website', 'this site', 'built with', 'how was this', 'source code', 'assistant', 'are you ai', 'chatbot', 'who are you'],
      ar: ['هذا الموقع', 'الموقع', 'الشيفره المصدريه', 'المساعد', 'هل انت ذكاء', 'من انت', 'روبوت'],
      es: ['este sitio', 'esta web', 'codigo fuente', 'asistente', 'eres una ia', 'quien eres', 'chatbot'],
    },
    answer: {
      en: 'This site is a static React + TypeScript build hosted for free. Its project gallery is generated by a scheduled workflow that reads public repositories from GitHub, GitLab, and Codeberg. I am a local assistant: I search a fixed, verified knowledge base in your browser. I am not a generative AI model and I do not send your questions anywhere.',
      ar: 'هذا الموقع مبني بـ React وTypeScript ويُستضاف مجاناً كموقع ثابت. يُولَّد معرض المشاريع عبر سير عمل مجدول يقرأ المستودعات العامة من GitHub وGitLab وCodeberg. أنا مساعد محلي: أبحث في قاعدة معرفة ثابتة ومؤكَّدة داخل متصفحك. لست نموذج ذكاء اصطناعي توليدياً ولا أرسل أسئلتك إلى أي مكان.',
      es: 'Este sitio es una compilación estática de React + TypeScript alojada gratis. La galería se genera con un flujo programado que lee los repositorios públicos de GitHub, GitLab y Codeberg. Soy un asistente local: busco en una base de conocimiento fija y verificada dentro de tu navegador. No soy un modelo de IA generativa y no envío tus preguntas a ningún sitio.',
    },
  },
];

/** Keywords that indicate a question is about projects in general. */
export const PROJECT_WORDS: Record<L, string[]> = {
  en: ['project', 'projects', 'repo', 'repos', 'repository', 'repositories', 'apps', 'app', 'built', 'portfolio', 'work on'],
  ar: ['مشروع', 'مشاريع', 'المشاريع', 'مستودع', 'مستودعات', 'تطبيق', 'تطبيقات', 'اعمال'],
  es: ['proyecto', 'proyectos', 'repositorio', 'repositorios', 'aplicacion', 'aplicaciones', 'apps'],
};
export const COUNT_WORDS: Record<L, string[]> = {
  en: ['how many', 'count', 'number of', 'total'],
  ar: ['كم', 'عدد'],
  es: ['cuantos', 'cuantas', 'numero', 'total'],
};
export const LATEST_WORDS: Record<L, string[]> = {
  en: ['latest', 'newest', 'recent', 'recently', 'last'],
  ar: ['اخر', 'احدث', 'جديد', 'الاحدث', 'اخيره', 'الاخيره', 'مؤخرا'],
  es: ['ultimo', 'reciente', 'recientes', 'nuevo'],
};
export const TECH_WORDS: Record<L, string[]> = {
  en: ['technologies', 'tech', 'stack', 'languages does', 'programming', 'skills', 'typescript', 'javascript', 'python', 'react', 'html'],
  ar: ['تقنيات', 'لغات البرمجه', 'مهارات', 'برمجه'],
  es: ['tecnologias', 'stack', 'lenguajes', 'programacion', 'habilidades'],
};
