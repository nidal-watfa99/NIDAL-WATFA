/**
 * Deterministic local retrieval engine for the site assistant.
 * No network calls, no generative model: it scores the question against the
 * structured knowledge base and the synced project index, then returns the
 * best verified answer — or says that it does not know.
 *
 * To plug in a generative model later, implement `AnswerProvider` on a server
 * (keys stay server-side) and call it only when `answer()` returns `kind: 'unknown'`.
 */
import { COUNT_WORDS, KB, LATEST_WORDS, PROJECT_WORDS, TECH_WORDS, type KBLink, type L } from './knowledge';
import type { Project, ProjectIndex } from '../lib/projects';

export interface Reply {
  kind: 'kb' | 'projects' | 'unknown';
  lang: L;
  text: string;
  links: KBLink[];
  projects: Project[];
  entryId?: string;
}

export type AnswerProvider = (q: string, lang: L) => Promise<Reply | null>;

const AR_DIACRITICS = /[\u0610-\u061A\u064B-\u065F\u0670\u06D6-\u06ED\u0640]/g;

export function normalize(s: string): string {
  return s
    .toLowerCase()
    .normalize('NFD')
    .replace(/[\u0300-\u036f]/g, '') // latin accents
    .replace(AR_DIACRITICS, '')
    .replace(/[أإآٱ]/g, 'ا')
    .replace(/ة/g, 'ه')
    .replace(/ى/g, 'ي')
    .replace(/ؤ/g, 'و')
    .replace(/ئ/g, 'ي')
    .replace(/[^\p{L}\p{N}.\s-]/gu, ' ')
    .replace(/[-_]/g, ' ')
    .replace(/\s+/g, ' ')
    .trim();
}

/** Strip common Arabic prefixes so "والمشاريع" matches "مشاريع". */
function stems(token: string): string[] {
  const out = [token];
  const m = token.match(/^(وال|بال|كال|فال|لل|ال|و|ب|ل|ف)(.{3,})$/);
  if (m) out.push(m[2]);
  if (token.length > 4 && /s$/.test(token)) out.push(token.slice(0, -1)); // projects → project
  return out;
}

export function tokenize(q: string): string[] {
  return normalize(q).split(' ').filter(Boolean).flatMap(stems);
}

export function detectLang(q: string, ui: L): L {
  if (/[\u0600-\u06FF]/.test(q)) return 'ar';
  if (/[¿¡ñ]|[áéíóú]/i.test(q)) return 'es';
  const n = ` ${normalize(q)} `;
  if (/ (que|como|donde|cual|quien|proyectos?|tiene|puedo|sobre|trabajo|habla|es) /.test(n) && ui !== 'en') return 'es';
  if (/ (que|como|donde|cual|quien|proyectos|puedo|contactarlo|ordenador) /.test(n)) return 'es';
  if (ui === 'ar') return 'en'; // Latin text typed while the interface is Arabic
  return ui;
}

// The owner's name appears in many questions, so it only counts as a weak signal.
const WEAK = new Set(['nidal', 'watfa', 'نضال', 'وطفه']);

function hits(qNorm: string, qTokens: Set<string>, kw: string): number {
  const k = normalize(kw);
  if (!k) return 0;
  if (WEAK.has(k)) return qTokens.has(k) ? 0.5 : 0;
  if (k.includes(' ')) return ` ${qNorm} `.includes(` ${k} `) ? 2 + k.split(' ').length * 0.5 : 0;
  if (qTokens.has(k)) return k.length >= 5 ? 1.6 : 1.2;
  if (k.length >= 5) for (const t of qTokens) if (t.length >= 5 && (t.startsWith(k) || k.startsWith(t))) return 0.9;
  return 0;
}

const anyHit = (qn: string, qt: Set<string>, words: string[]) => words.some((w) => hits(qn, qt, w) > 0);

function projectScore(p: Project, qNorm: string, qTokens: Set<string>): number {
  const name = normalize(p.name);
  const compact = name.replace(/\s/g, '');
  let s = 0;
  const parts = name.split(' ').filter((x) => !WEAK.has(x));
  if (!parts.length) return 0; // e.g. the "NIDAL-WATFA" profile repository: questions about the person go to the KB
  if (qNorm.replace(/\s/g, '').includes(compact) && compact.length >= 4) s += 5;
  for (const part of parts) if (part.length >= 4 && qTokens.has(part)) s += 2.5;
  for (const lang of [...p.languages, ...(p.tags || [])]) if (qTokens.has(normalize(lang))) s += 0.6;
  const desc = normalize([p.description, ...Object.values(p.descriptions || {})].filter(Boolean).join(' '));
  if (desc) for (const t of qTokens) if (t.length >= 4 && desc.includes(t)) s += 0.5;
  return s;
}

export interface Strings {
  unknown: string;
  projectsFound: (n: number) => string;
  projectCount: (n: number, gh: number, gl: number, cb: number) => string;
  latest: (name: string, date: string) => string;
  formatDate: (iso: string) => string;
}

export function answer(query: string, uiLang: L, index: ProjectIndex | null, S: Record<L, Strings>): Reply {
  const lang = detectLang(query, uiLang);
  const str = S[lang];
  const qNorm = normalize(query);
  const qTokens = new Set(tokenize(query));
  const allLangs: L[] = ['en', 'ar', 'es'];
  const projects = index?.projects ?? [];
  const isProjectQ = allLangs.some((l) => anyHit(qNorm, qTokens, PROJECT_WORDS[l]));

  // 1. Aggregate project questions: count / latest / technologies.
  if (index && isProjectQ && allLangs.some((l) => anyHit(qNorm, qTokens, COUNT_WORDS[l]))) {
    const c = (pl: string) => index.sources?.[pl as 'github']?.count ?? 0;
    return { kind: 'projects', lang, text: str.projectCount(projects.length, c('github'), c('gitlab'), c('codeberg')), links: [projLink], projects: [] };
  }
  if (index && isProjectQ && allLangs.some((l) => anyHit(qNorm, qTokens, LATEST_WORDS[l]))) {
    const sorted = [...projects].sort((a, b) => +new Date(b.updatedAt) - +new Date(a.updatedAt));
    const p = sorted[0];
    if (p) return { kind: 'projects', lang, text: str.latest(p.name, str.formatDate(p.updatedAt)), links: [projLink], projects: sorted.slice(0, 3) };
  }

  // 2. Specific project names (e.g. "AeroX", "NEXUS", "calculator").
  const scored = projects
    .map((p) => ({ p, s: projectScore(p, qNorm, qTokens) }))
    .filter((x) => x.s >= 2.5)
    .sort((a, b) => b.s - a.s);

  // 3. Knowledge-base entries.
  let best: { id: string; score: number } | null = null;
  for (const e of KB) {
    let score = 0;
    for (const l of allLangs) for (const kw of e.keywords[l]) score += hits(qNorm, qTokens, kw);
    if (score > 0) score += e.boost ?? 0;
    if (!best || score > best.score) best = { id: e.id, score };
  }

  // Technologies used across projects
  if (index && allLangs.some((l) => anyHit(qNorm, qTokens, TECH_WORDS[l])) && (!best || best.score < 3) && !scored.length) {
    const counts = new Map<string, number>();
    for (const p of projects) for (const t of p.tags?.length ? p.tags : p.languages) counts.set(t, (counts.get(t) || 0) + 1);
    const list = [...counts.entries()].sort((a, b) => b[1] - a[1]).slice(0, 8).map(([k, v]) => `${k} (${v})`).join(', ');
    const lead = { en: 'Languages and technologies detected in his public repositories:', ar: 'اللغات والتقنيات المكتشفة في مستودعاته العامة:', es: 'Lenguajes y tecnologías detectados en sus repositorios públicos:' }[lang];
    return { kind: 'projects', lang, text: `${lead} ${list}.`, links: [projLink], projects: [] };
  }

  const kbStrong = best && best.score >= 1.2;
  const topProject = scored[0];
  if (topProject && (!kbStrong || topProject.s >= (best?.score ?? 0))) {
    const list = scored.slice(0, 4).map((x) => x.p);
    // Veyra has a richer KB entry
    if (list[0].id === 'veyraai') return kbReply('veyra', lang);
    return { kind: 'projects', lang, text: str.projectsFound(list.length), links: [projLink], projects: list };
  }
  if (kbStrong) return kbReply(best!.id, lang);

  if (isProjectQ && projects.length) {
    const sorted = [...projects].sort((a, b) => (+b.featured - +a.featured) || +new Date(b.updatedAt) - +new Date(a.updatedAt));
    return { kind: 'projects', lang, text: str.projectCount(projects.length, index!.sources?.github?.count ?? 0, index!.sources?.gitlab?.count ?? 0, index!.sources?.codeberg?.count ?? 0), links: [projLink], projects: sorted.slice(0, 4) };
  }

  return { kind: 'unknown', lang, text: str.unknown, links: [sectionLinks.about, projLink, sectionLinks.contact], projects: [] };
}

const projLink: KBLink = { label: { en: 'Project gallery', ar: 'معرض المشاريع', es: 'Galería de proyectos' }, href: '#projects' };
const sectionLinks = {
  about: { label: { en: 'About', ar: 'من أنا', es: 'Sobre mí' }, href: '#about' } as KBLink,
  contact: { label: { en: 'Contact', ar: 'تواصل', es: 'Contacto' }, href: '#contact' } as KBLink,
};

function kbReply(id: string, lang: L): Reply {
  const e = KB.find((x) => x.id === id)!;
  return { kind: 'kb', lang, text: e.answer[lang], links: e.links ?? [], projects: [], entryId: id };
}
