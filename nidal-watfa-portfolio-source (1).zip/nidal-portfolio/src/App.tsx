import { useEffect, useState } from 'react';
import { useI18n } from './i18n';
import { useProjects } from './lib/projects';
import { Header } from './components/Header';
import { Hero } from './components/Hero';
import { Ecosystem } from './components/Ecosystem';
import { Featured } from './components/Featured';
import { Gallery } from './components/Gallery';
import { About } from './components/About';
import { Experience } from './components/Experience';
import { Contact } from './components/Contact';
import { Footer } from './components/Footer';
import { Assistant } from './components/Assistant';
import { IconArrowUp } from './components/Icons';

function useReveal(dep: unknown) {
  useEffect(() => {
    const els = document.querySelectorAll('.reveal:not(.in)');
    if (!('IntersectionObserver' in window)) { els.forEach((e) => e.classList.add('in')); return; }
    const io = new IntersectionObserver((entries) => {
      for (const en of entries) if (en.isIntersecting) { en.target.classList.add('in'); io.unobserve(en.target); }
    }, { rootMargin: '0px 0px -8% 0px', threshold: 0.05 });
    els.forEach((e) => io.observe(e));
    return () => io.disconnect();
  }, [dep]);
}

export default function App() {
  const { t, lang } = useI18n();
  const projects = useProjects();
  const [chatOpen, setChatOpen] = useState(false);
  const [showTop, setShowTop] = useState(false);
  useReveal(lang);

  useEffect(() => {
    const onScroll = () => setShowTop(window.scrollY > 700);
    onScroll();
    window.addEventListener('scroll', onScroll, { passive: true });
    return () => window.removeEventListener('scroll', onScroll);
  }, []);

  return (
    <>
      <Header />
      <main id="main" tabIndex={-1}>
        <Hero />
        <div className="divider" />
        <Ecosystem />
        <Featured />
        <div className="divider" />
        <Gallery data={projects} />
        <div className="divider" />
        <About />
        <Experience />
        <div className="divider" />
        <Contact />
      </main>
      <Footer />
      <div className="fab-stack">
        {!chatOpen && (
          <a href="#home" className="to-top" data-show={showTop} aria-label={t.nav.backToTop} tabIndex={showTop ? 0 : -1}>
            <IconArrowUp />
          </a>
        )}
        <Assistant data={projects} open={chatOpen} setOpen={setChatOpen} />
      </div>
    </>
  );
}
