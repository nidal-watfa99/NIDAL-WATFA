/**
 * Language-neutral facts about Nidal Watfa.
 * Text that visitors read lives in src/i18n/*.ts — this file only holds
 * identifiers, URLs and dates so they are never duplicated per language.
 */
export const EMAIL = 'nidalwatfa99@gmail.com';

export type PlatformId = 'github' | 'gitlab' | 'codeberg' | 'orcid' | 'linkedin' | 'x';

export interface PlatformProfile {
  id: PlatformId;
  name: string;
  handle: string;
  url: string;
}

export const PROFILES: PlatformProfile[] = [
  { id: 'github', name: 'GitHub', handle: 'nidal-watfa99', url: 'https://github.com/nidal-watfa99' },
  { id: 'gitlab', name: 'GitLab', handle: 'nidalwatfa', url: 'https://gitlab.com/nidalwatfa' },
  { id: 'codeberg', name: 'Codeberg', handle: 'nidalwatfa', url: 'https://codeberg.org/nidalwatfa' },
  { id: 'orcid', name: 'ORCID', handle: '0009-0003-2462-6630', url: 'https://orcid.org/0009-0003-2462-6630' },
  { id: 'linkedin', name: 'LinkedIn', handle: 'nidal-watfa-a91720301', url: 'https://www.linkedin.com/in/nidal-watfa-a91720301' },
  { id: 'x', name: 'X', handle: '@NidalWatfa12501', url: 'https://x.com/NidalWatfa12501' },
];

export const FEATURED = {
  id: 'veyraai',
  name: 'Veyra AI',
  repo: 'https://github.com/nidal-watfa99/Veyra-ai',
  demo: 'https://nidal-watfa99.github.io/Veyra-ai/',
  // Verified from the repository's package.json and README (October 2026).
  tags: ['TypeScript', 'React 19', 'Vite', 'Tailwind CSS', 'Express', 'PWA'],
  preview: 'assets/veyra-preview.webp',
};

export const JOURNEY = { start: '1994-07-03', end: '2010-07-03' };

/** Destination keys; labels are translated in i18n `destinations`. */
export const DESTINATIONS = [
  'paris', 'netherlands', 'spain', 'egypt', 'ethiopia', 'cameroon', 'gabon', 'morocco', 'lebanon',
] as const;
export type DestinationId = (typeof DESTINATIONS)[number];

export const TOOLS = ['Termux', 'Acode', 'Git', 'AI-assisted coding'];

/** Set this to the public repository of this website once it is published (shown in the footer). */
export const SITE_REPO: string | null = null;
