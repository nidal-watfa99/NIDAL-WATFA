# Nidal Watfa — Portfolio, Project Hub & Local Assistant

A trilingual (English / العربية / Español) personal website for **Nidal Watfa**, built with React + TypeScript + Vite.
It is a static site: no server, no paid service, no credit card. It can be maintained entirely from an Android phone.

- **Project gallery** gathered automatically from public repositories on GitHub (`nidal-watfa99`), GitLab (`nidalwatfa`) and Codeberg (`nidalwatfa`).
- **Local site assistant** that answers questions from a verified knowledge base, in the visitor's language. It runs entirely in the browser and is **not** a generative AI model.
- **Real language switching**: all text, the layout direction (RTL for Arabic), dates and assistant answers change.

---

## Folder map

```
.github/workflows/deploy.yml   Scheduled sync + build + GitHub Pages deploy
data/curated.json              Your manual choices: featured projects, hidden repos, aliases
public/data/projects.json      Generated project index (committed; last valid copy is kept)
public/assets/                 Images (Veyra screenshot, About illustration)
scripts/sync-projects.mjs      Fetches + normalises + de-duplicates repositories
scripts/build-map.mjs          One-off generator for the map outline (already generated)
src/i18n/en.ts | ar.ts | es.ts All visible text, one file per language
src/content/profile.ts         Links, email, Veyra facts, destinations
src/assistant/knowledge.ts     Assistant knowledge base (verified facts only)
src/assistant/engine.ts        Local search / answer selection
src/components/                Header, Hero, Ecosystem, Featured, Gallery, About, Experience, Contact, Footer, Assistant
src/styles/global.css          Design tokens and all styles
tests/                         Unit tests (sync merge rules, assistant answers)
```

---

## Work on it from your phone (Termux)

```bash
pkg update && pkg install nodejs-lts git
git clone https://github.com/nidal-watfa99/<your-repo>.git
cd <your-repo>
npm ci                 # install (once)
npm run sync           # refresh public/data/projects.json from the 3 platforms
npm run dev -- --host  # preview: open http://127.0.0.1:5173 in your phone browser
npm test               # run the tests
npm run build          # production build into dist/
```

Edit files with **Acode** (open the project folder from Termux storage, or run `termux-setup-storage` and keep the project under `~/storage/shared/`).

Needs Node.js 20 or newer (`node -v`).

---

## Publish on GitHub Pages (free)

1. **Create a repository.**
   - Named `nidal-watfa99.github.io` → the site lives at `https://nidal-watfa99.github.io/` (recommended — no domain needed).
   - Any other name (e.g. `portfolio`) → `https://nidal-watfa99.github.io/portfolio/`. Both work without changes because the build uses relative paths.
2. **Push this folder** from Termux:
   ```bash
   git init && git add -A && git commit -m "Portfolio"
   git branch -M main
   git remote add origin https://github.com/nidal-watfa99/nidal-watfa99.github.io.git
   git push -u origin main
   ```
   GitHub asks for a password: use a **Personal Access Token** (GitHub → Settings → Developer settings → Fine-grained tokens, access to this repository, "Contents: Read and write"). Paste it only into the Termux prompt. **Never put a token in any file of this project.**
3. **Turn on Pages:** repository → Settings → Pages → Build and deployment → Source: **GitHub Actions**.
4. **Run it:** Actions tab → "Sync projects & deploy" → **Run workflow**. After it turns green, the site is live.
5. Optional: set `SITE_REPO` in `src/content/profile.ts` to the repository URL so the footer shows a "Source code" link.

### What the workflow does

| Step | Detail |
|---|---|
| Triggers | Every push to `main`, every 6 hours, the manual **Run workflow** button, or a `repository_dispatch` event of type `sync-projects`. |
| Sync | Calls the public APIs of GitHub, GitLab and Codeberg. The automatic `GITHUB_TOKEN` is used only on the runner to raise GitHub's rate limit. |
| Test + build | `npm test`, then `npm run build`. If tests fail, nothing is deployed. |
| Keep last valid data | If one platform is down, its projects from the previous index are kept and the site shows a small notice. If all three fail, the old index is left untouched. |
| Commit index | A changed `public/data/projects.json` is committed back with `[skip ci]`, so the last valid index always lives in git. |
| Deploy | Publishes `dist/` to GitHub Pages. |

**New projects appear automatically** at the next run (within ~6 hours) once they are public on any of the three platforms. To see them immediately, press **Run workflow**.

> GitHub pauses scheduled workflows in repositories with no activity for 60 days. If that happens, open the Actions tab and re-enable the workflow (or push any commit).

---

## Curating projects — `data/curated.json`

Project keys are "slugs": the repository name in lowercase with only letters and digits (`Veyra-ai` → `veyraai`, `AeroX-Weather` → `aeroxweather`).

```json
{
  "overrides": {
    "veyraai": {
      "featured": true,
      "previewImage": "assets/veyra-preview.webp",
      "tags": ["TypeScript", "React 19", "Vite"],
      "descriptions": { "en": "…", "ar": "…", "es": "…" }
    }
  },
  "aliases": { "aerox": "aeroxweather" },
  "hidden": ["some-test-repo"]
}
```

- `featured` puts a project first with a highlighted card.
- `tags` replace the auto-detected languages — use only technologies you have verified.
- `descriptions` add translated descriptions; otherwise the repository's own description is shown as-is.
- `aliases` merges repositories with different names that are the same project.
- `hidden` removes a repository from the site.

**Duplicates:** repositories with the same slug on several platforms become one card. GitHub is the primary link, then Codeberg, then GitLab; the others appear as "Also on" icons. Forks, private repositories and empty Codeberg repositories are skipped.

---

## Editing text and translations

- All interface text: `src/i18n/en.ts`, `ar.ts`, `es.ts`. The three files must have the same keys — `npm run build` fails if one is missing, which protects you from half-translated pages.
- Links, email, Veyra facts: `src/content/profile.ts`.
- The selected language is remembered and can be linked directly: `?lang=ar`, `?lang=es`, `?lang=en`.

## The assistant

- Answers come only from `src/assistant/knowledge.ts` and the synced project index. To teach it something, add an entry with keywords in all three languages and an answer in all three languages, then add a test in `tests/assistant.test.ts`.
- If no entry matches, it says it does not have verified information. It never makes up an answer.
- Arabic questions are answered in Arabic, Spanish questions in Spanish; otherwise the current page language is used.
- **Adding a real AI model later:** a model needs an API key, and keys must never be in this public site. Put a small server or serverless function in between (it holds the key), and call it from `engine.ts` only when the local answer is `unknown`. The `AnswerProvider` type in `engine.ts` marks that extension point.

## Contact form

The form does not send anything itself: it opens the visitor's email app with the message filled in (`mailto:`), so no server or third-party form service is needed. The email address and a copy button are shown as well.

---

## Codeberg Pages (alternative)

Codeberg serves static sites from a branch named `pages`:

```bash
npm run sync && npm run build
cd dist && git init && git checkout -b pages && git add -A && git commit -m "Deploy"
git push -f https://codeberg.org/nidalwatfa/<repo>.git pages
```

The site appears at `https://nidalwatfa.codeberg.page/<repo>/`. Automatic scheduled sync on Codeberg would need Codeberg CI (Woodpecker), which requires a separate access request — until then, run the commands above when you want to refresh.

---

## Troubleshooting

| Problem | Fix |
|---|---|
| Workflow fails at "Deploy" with a Pages error | Settings → Pages → Source must be **GitHub Actions**. |
| Push rejected after the bot committed the index | `git pull --rebase` then push again. |
| A platform notice appears in the gallery | That API was unreachable during the last sync. Old data is shown; the next run fixes it. |
| Sync is slow or rate-limited locally | GitHub allows 60 unauthenticated requests per hour. In Termux you may run `GITHUB_TOKEN=<token> npm run sync` (the token stays in your shell, it is not saved). |
| Test the failure handling | `SYNC_OUT=/tmp/test.json SYNC_SIMULATE_FAIL=gitlab npm run sync` |
| `npm ci` fails in Termux | Run `pkg upgrade nodejs-lts`, then `rm -rf node_modules && npm ci`. |

## Image and data credits

- Platform logos: Simple Icons (CC0). Map outline: Natural Earth via `world-atlas` (public domain).
- Veyra AI screenshot: captured from the public demo at https://nidal-watfa99.github.io/Veyra-ai/ (sample data).
- About illustration: AI-generated artwork, replaceable at `public/assets/about-layers.webp`.
