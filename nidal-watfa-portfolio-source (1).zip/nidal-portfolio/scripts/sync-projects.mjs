#!/usr/bin/env node
/**
 * Project synchronization for the Nidal Watfa portfolio.
 *
 * Fetches PUBLIC repository metadata from GitHub, GitLab and Codeberg,
 * normalizes it into one data model, merges duplicates (same project
 * published on several platforms), applies manual curation from
 * data/curated.json and writes public/data/projects.json.
 *
 * Safety rules:
 *  - If a platform fails, the entries previously synced for that platform
 *    are kept from the last valid index (nothing is erased).
 *  - If every platform fails, the existing index is left untouched and the
 *    script exits with code 0 (so the deploy still publishes the last good data),
 *    unless --strict is passed.
 *  - Tokens are optional, read only from environment variables on the server
 *    or CI runner and never written to the output.
 *
 * Usage:  node scripts/sync-projects.mjs [--strict] [--dry-run]
 */
import { readFile, writeFile, mkdir, rename } from 'node:fs/promises';
import { existsSync } from 'node:fs';
import { dirname, join } from 'node:path';
import { fileURLToPath } from 'node:url';

const ROOT = join(dirname(fileURLToPath(import.meta.url)), '..');
const OUT = process.env.SYNC_OUT || join(ROOT, 'public', 'data', 'projects.json');
const CURATED = join(ROOT, 'data', 'curated.json');
const SCHEMA_VERSION = 1;
const args = new Set(process.argv.slice(2));

const ACCOUNTS = {
  github: 'nidal-watfa99',
  gitlab: 'nidalwatfa',
  codeberg: 'nidalwatfa',
};

const UA = 'nidal-watfa-portfolio-sync (+https://github.com/nidal-watfa99)';

async function getJSON(url, headers = {}) {
  const ctrl = new AbortController();
  const timer = setTimeout(() => ctrl.abort(), 20000);
  try {
    const res = await fetch(url, {
      headers: { 'User-Agent': UA, Accept: 'application/json', ...headers },
      signal: ctrl.signal,
    });
    if (!res.ok) throw new Error(`${res.status} ${res.statusText} for ${url}`);
    return await res.json();
  } finally {
    clearTimeout(timer);
  }
}

/** Convert a byte-count language map into an ordered list of names (>=3% share). */
function topLanguages(map) {
  if (!map || typeof map !== 'object') return [];
  const entries = Object.entries(map);
  const total = entries.reduce((s, [, v]) => s + Number(v || 0), 0) || 1;
  // GitLab returns percentages, GitHub/Codeberg return bytes; both work as weights.
  return entries
    .filter(([, v]) => Number(v) / total >= 0.03)
    .sort((a, b) => Number(b[1]) - Number(a[1]))
    .map(([k]) => k)
    .slice(0, 5);
}

/** Plain-text description: strips Markdown markup that some repositories put in the short description. */
export const clean = (s) => {
  if (typeof s !== 'string') return null;
  const t = s
    .replace(/\r\n?/g, '\n')
    .replace(/^\s{0,3}#{1,6}\s*/gm, '')
    .replace(/\*\*|__|`/g, '')
    .replace(/\[([^\]]+)\]\([^)]+\)/g, '$1')
    .replace(/[ \t]+/g, ' ')
    .replace(/\n{2,}/g, '\n')
    .trim();
  return t || null;
};
const cleanUrl = (s) => (typeof s === 'string' && /^https?:\/\//.test(s.trim()) ? s.trim() : null);

/* ---------------- Platform adapters ---------------- */

async function fetchGitHub() {
  const headers = { Accept: 'application/vnd.github+json' };
  if (process.env.GITHUB_TOKEN) headers.Authorization = `Bearer ${process.env.GITHUB_TOKEN}`;
  const repos = await getJSON(
    `https://api.github.com/users/${ACCOUNTS.github}/repos?per_page=100&type=owner&sort=pushed`,
    headers,
  );
  const out = [];
  for (const r of repos) {
    if (r.private || r.fork) continue;
    let languages = r.language ? [r.language] : [];
    try {
      languages = topLanguages(await getJSON(r.languages_url, headers)) || languages;
    } catch { /* keep primary language */ }
    out.push({
      name: r.name,
      platform: 'github',
      url: r.html_url,
      description: clean(r.description),
      languages,
      topics: Array.isArray(r.topics) ? r.topics : [],
      updatedAt: r.pushed_at || r.updated_at,
      createdAt: r.created_at,
      archived: !!r.archived,
      demoUrl: cleanUrl(r.homepage),
      stars: r.stargazers_count ?? null,
    });
  }
  return out;
}

async function fetchGitLab() {
  const headers = {};
  if (process.env.GITLAB_TOKEN) headers['PRIVATE-TOKEN'] = process.env.GITLAB_TOKEN;
  const users = await getJSON(`https://gitlab.com/api/v4/users?username=${ACCOUNTS.gitlab}`, headers);
  if (!users.length) throw new Error('GitLab user not found');
  const projects = await getJSON(
    `https://gitlab.com/api/v4/users/${users[0].id}/projects?per_page=100&visibility=public&order_by=last_activity_at`,
    headers,
  );
  const out = [];
  for (const p of projects) {
    if (p.forked_from_project) continue;
    let languages = [];
    try {
      languages = topLanguages(await getJSON(`https://gitlab.com/api/v4/projects/${p.id}/languages`, headers));
    } catch { /* optional */ }
    out.push({
      name: p.name,
      platform: 'gitlab',
      url: p.web_url,
      description: clean(p.description),
      languages,
      topics: Array.isArray(p.topics) ? p.topics : [],
      updatedAt: p.last_activity_at,
      createdAt: p.created_at,
      archived: !!p.archived,
      demoUrl: null,
      stars: p.star_count ?? null,
    });
  }
  return out;
}

async function fetchCodeberg() {
  const headers = {};
  if (process.env.CODEBERG_TOKEN) headers.Authorization = `token ${process.env.CODEBERG_TOKEN}`;
  const repos = await getJSON(`https://codeberg.org/api/v1/users/${ACCOUNTS.codeberg}/repos?limit=50`, headers);
  const out = [];
  for (const r of repos) {
    if (r.private || r.fork || r.mirror || r.empty) continue;
    let languages = r.language ? [r.language] : [];
    try {
      const l = topLanguages(await getJSON(r.languages_url, headers));
      if (l.length) languages = l;
    } catch { /* keep primary */ }
    out.push({
      name: r.name,
      platform: 'codeberg',
      url: r.html_url,
      description: clean(r.description),
      languages,
      topics: Array.isArray(r.topics) ? r.topics : [],
      updatedAt: r.updated_at,
      createdAt: r.created_at,
      archived: !!r.archived,
      demoUrl: cleanUrl(r.website),
      stars: r.stars_count ?? null,
    });
  }
  return out;
}

/* ---------------- Normalization & merge ---------------- */

/** Slug used to detect the same project published on several platforms. */
export function slugOf(name) {
  return String(name)
    .toLowerCase()
    .replace(/\.git$/, '')
    .replace(/[^a-z0-9\u0600-\u06ff]+/g, '');
}

const PLATFORM_PRIORITY = { github: 0, codeberg: 1, gitlab: 2 };

export function mergeProjects(raw, curated = {}) {
  const hidden = new Set((curated.hidden || []).map(slugOf));
  const aliases = Object.fromEntries(
    Object.entries(curated.aliases || {}).map(([k, v]) => [slugOf(k), slugOf(v)]),
  );
  const groups = new Map();
  for (const item of raw) {
    let slug = slugOf(item.name);
    slug = aliases[slug] || slug;
    if (hidden.has(slug)) continue;
    if (!groups.has(slug)) groups.set(slug, []);
    groups.get(slug).push(item);
  }

  const projects = [];
  for (const [slug, items] of groups) {
    items.sort((a, b) => PLATFORM_PRIORITY[a.platform] - PLATFORM_PRIORITY[b.platform]);
    const primary = items[0];
    const newest = items.reduce((m, i) => (new Date(i.updatedAt) > new Date(m.updatedAt) ? i : m), primary);
    const languages = [...new Set(items.flatMap((i) => i.languages))].slice(0, 6);
    const override = (curated.overrides || {})[slug] || {};
    const p = {
      id: slug,
      name: primary.name.replace(/\.git$/, ''),
      platform: primary.platform,
      url: primary.url,
      description: items.map((i) => i.description).find(Boolean) ?? null,
      languages,
      topics: [...new Set(items.flatMap((i) => i.topics))].slice(0, 8),
      updatedAt: newest.updatedAt,
      createdAt: items.map((i) => i.createdAt).filter(Boolean).sort()[0] ?? null,
      status: items.every((i) => i.archived) ? 'archived' : 'active',
      demoUrl: items.map((i) => i.demoUrl).find(Boolean) ?? null,
      previewImage: null,
      featured: false,
      mirrors: items.slice(1).map((i) => ({ platform: i.platform, url: i.url })),
      platforms: [...new Set(items.map((i) => i.platform))],
    };
    // Manual curation always wins, but only for the fields it sets.
    for (const key of ['description', 'descriptions', 'demoUrl', 'previewImage', 'featured', 'tags', 'name']) {
      if (override[key] !== undefined) p[key] = override[key];
    }
    projects.push(p);
  }
  projects.sort((a, b) => (b.featured - a.featured) || new Date(b.updatedAt) - new Date(a.updatedAt));
  return projects;
}

async function readJSON(path, fallback) {
  try {
    return JSON.parse(await readFile(path, 'utf8'));
  } catch {
    return fallback;
  }
}

async function main() {
  const curated = await readJSON(CURATED, {});
  const previous = await readJSON(OUT, null);
  const previousRaw = previous?.raw || [];

  const adapters = { github: fetchGitHub, gitlab: fetchGitLab, codeberg: fetchCodeberg };
  const sources = {};
  let raw = [];
  let okCount = 0;

  for (const [platform, fn] of Object.entries(adapters)) {
    try {
      // SYNC_SIMULATE_FAIL=gitlab,codeberg lets you test the failure path safely.
      if ((process.env.SYNC_SIMULATE_FAIL || '').split(',').includes(platform)) throw new Error('simulated outage');
      const items = await fn();
      raw.push(...items);
      sources[platform] = { status: 'ok', count: items.length, syncedAt: new Date().toISOString() };
      okCount++;
      console.log(`✓ ${platform}: ${items.length} public repositories`);
    } catch (err) {
      const kept = previousRaw.filter((i) => i.platform === platform);
      raw.push(...kept);
      sources[platform] = {
        status: 'error',
        error: String(err.message || err).slice(0, 200),
        count: kept.length,
        syncedAt: previous?.sources?.[platform]?.syncedAt ?? null,
      };
      console.warn(`✗ ${platform}: ${err.message} — kept ${kept.length} entries from last valid index`);
    }
  }

  if (okCount === 0) {
    console.error('All platforms failed. Leaving the last valid index untouched.');
    process.exit(args.has('--strict') ? 1 : 0);
  }

  const projects = mergeProjects(raw, curated);
  const index = {
    schemaVersion: SCHEMA_VERSION,
    generatedAt: new Date().toISOString(),
    accounts: ACCOUNTS,
    sources,
    count: projects.length,
    projects,
    raw, // per-platform records, used to preserve data when a platform fails next time
  };

  if (args.has('--dry-run')) {
    console.log(JSON.stringify({ ...index, raw: undefined }, null, 2));
    return;
  }
  await mkdir(dirname(OUT), { recursive: true });
  const tmp = OUT + '.tmp';
  await writeFile(tmp, JSON.stringify(index, null, 2) + '\n');
  await rename(tmp, OUT); // atomic replace: a crash never leaves a half-written index
  console.log(`Wrote ${projects.length} merged projects (${raw.length} repositories) → ${OUT}`);
}

if (process.argv[1] && fileURLToPath(import.meta.url) === process.argv[1]) {
  main().catch((err) => {
    console.error('Sync crashed:', err);
    console.error(existsSync(OUT) ? 'Existing index preserved.' : 'No index exists yet.');
    process.exit(args.has('--strict') ? 1 : 0);
  });
}
