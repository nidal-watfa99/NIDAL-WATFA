import { test } from 'node:test';
import assert from 'node:assert/strict';
import { mergeProjects, slugOf, clean } from '../scripts/sync-projects.mjs';

const r = (name, platform, updatedAt, extra = {}) => ({ name, platform, url: `https://${platform}.example/${name}`, description: null, languages: [], topics: [], updatedAt, createdAt: updatedAt, archived: false, demoUrl: null, ...extra });

test('slug ignores case, punctuation and .git suffix', () => {
  assert.equal(slugOf('NEXUS-INTERNATIONAL'), slugOf('nexus-international'));
  assert.equal(slugOf('aero-x.git'), slugOf('AERO-X'));
});

test('duplicates across platforms merge into one project with mirrors', () => {
  const out = mergeProjects([
    r('NEXUS-INTERNATIONAL', 'gitlab', '2026-03-01T00:00:00Z', { description: 'gl' }),
    r('NEXUS-INTERNATIONAL', 'github', '2026-10-03T00:00:00Z', { languages: ['HTML'] }),
    r('NEXUS-INTERNATIONAL', 'codeberg', '2026-10-02T00:00:00Z', { description: 'cb' }),
  ]);
  assert.equal(out.length, 1);
  const p = out[0];
  assert.equal(p.platform, 'github', 'GitHub is the primary source');
  assert.deepEqual(p.platforms.sort(), ['codeberg', 'github', 'gitlab']);
  assert.equal(p.mirrors.length, 2);
  assert.equal(p.updatedAt, '2026-10-03T00:00:00Z', 'newest update wins');
  assert.equal(p.description, 'cb', 'first available description in priority order');
});

test('curation sets featured and hides, without inventing data', () => {
  const out = mergeProjects(
    [r('Veyra-ai', 'github', '2026-10-13T00:00:00Z'), r('secret-test', 'github', '2026-10-14T00:00:00Z'), r('other', 'github', '2026-10-15T00:00:00Z')],
    { overrides: { veyraai: { featured: true, tags: ['React'] } }, hidden: ['secret-test'] },
  );
  assert.equal(out.length, 2);
  assert.equal(out[0].id, 'veyraai', 'featured first');
  assert.equal(out[0].featured, true);
  assert.deepEqual(out[0].tags, ['React']);
  assert.equal(out[1].description, null);
});

test('markdown is stripped from descriptions', () => {
  assert.equal(clean('### **Hello** `world`'), 'Hello world');
  assert.equal(clean('   '), null);
});
