import { test } from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import { answer, detectLang, normalize, type Strings } from '../src/assistant/engine';

const index = JSON.parse(readFileSync(new URL('../public/data/projects.json', import.meta.url), 'utf8'));
const S: Strings = { unknown: 'UNKNOWN', projectsFound: (n) => `FOUND ${n}`, projectCount: (n) => `COUNT ${n}`, latest: (n) => `LATEST ${n}`, formatDate: (d) => d };
const SS = { en: S, ar: { ...S, unknown: 'AR_UNKNOWN' }, es: { ...S, unknown: 'ES_UNKNOWN' } };
const ask = (q: string, ui: 'en' | 'ar' | 'es' = 'en') => answer(q, ui, index, SS);

test('normalization handles Arabic and Spanish forms', () => {
  assert.equal(normalize('إسبانيّة'), 'اسبانيه');
  assert.equal(normalize('¿Dónde?'), 'donde');
});

test('language detection', () => {
  assert.equal(detectLang('ما هو Veyra؟', 'en'), 'ar');
  assert.equal(detectLang('¿Qué es Veyra AI?', 'en'), 'es');
  assert.equal(detectLang('What is Veyra?', 'es'), 'es');
  assert.equal(detectLang('What is Veyra?', 'ar'), 'en');
});

const cases: [string, 'en' | 'ar' | 'es', string][] = [
  ['What is Veyra AI?', 'en', 'veyra'],
  ['ما هو Veyra AI؟', 'ar', 'veyra'],
  ['¿Qué es Veyra AI?', 'es', 'veyra'],
  ['Where did Nidal work?', 'en', 'work'],
  ['أين عمل نضال؟', 'ar', 'work'],
  ['Tell me about Bisila Palace', 'en', 'bisila'],
  ['Rio Muni Timberland', 'es', 'riomuni'],
  ['Does he speak Spanish?', 'en', 'spanish'],
  ['هل يتكلم الإسبانية؟', 'ar', 'spanish'],
  ['How does he code without a computer?', 'en', 'phone'],
  ['كيف يبرمج من دون حاسوب؟', 'ar', 'phone'],
  ['¿Cómo programa sin ordenador?', 'es', 'phone'],
  ['What is Termux?', 'en', 'phone'],
  ['How can I contact him?', 'en', 'contact'],
  ['كيف أتواصل معه؟', 'ar', 'contact'],
  ['¿Cómo puedo contactarlo?', 'es', 'contact'],
  ['Which countries did he visit?', 'en', 'travel'],
  ['What is his ORCID?', 'en', 'profile-orcid'],
  ['Are you an AI chatbot?', 'en', 'site'],
];
for (const [q, ui, id] of cases) {
  test(`KB: "${q}" → ${id}`, () => {
    const r = ask(q, ui);
    assert.equal(r.kind, 'kb', `${q} gave ${r.kind}: ${r.text.slice(0, 60)}`);
    assert.equal(r.entryId, id);
  });
}

test('project lookups by name', () => {
  const r = ask('Tell me about AeroX Weather');
  assert.equal(r.kind, 'projects');
  assert.ok(r.projects.some((p) => p.id === 'aeroxweather'));
  const r2 = ask('calculator');
  assert.ok(r2.projects.some((p) => p.id === 'calculatorapp'));
});

test('project count & latest', () => {
  assert.equal(ask('How many projects does he have?').text, `COUNT ${index.projects.length}`);
  assert.match(ask('What is his latest project?').text, /^LATEST /);
  assert.match(ask('كم عدد المشاريع؟', 'ar').text, /^COUNT /);
});

test('unknown questions are not answered with invented facts', () => {
  assert.equal(ask('What is his favourite football team?').kind, 'unknown');
  assert.equal(ask('ما هو طعامه المفضل؟', 'ar').text, 'AR_UNKNOWN');
});

test('Arabic "latest projects" phrasing', () => {
  assert.match(ask('ما هي مشاريعه الأخيرة؟', 'ar').text, /^LATEST /);
});
